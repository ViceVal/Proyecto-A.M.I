import serial
import serial.tools.list_ports

def listar_puertos():
    print("🔍 Buscando puertos seriales disponibles...")
    puertos = serial.tools.list_ports.comports()
    
    if not puertos:
        print("❌ No se encontraron puertos seriales")
        return
    
    for i, puerto in enumerate(puertos):
        print(f"{i+1}. {puerto.device} - {puerto.description}")
    
    return [p.device for p in puertos]

def probar_conexion(puerto):
    print(f"🔌 Probando conexión con {puerto}...")
    try:
        ser = serial.Serial(puerto, 115200, timeout=2)
        print(f"✅ Conectado exitosamente a {puerto}")
        
        # Esperar mensaje de inicialización
        print("⏳ Esperando mensaje del ESP32...")
        for i in range(5):
            if ser.in_waiting > 0:
                mensaje = ser.readline().decode('utf-8').strip()
                print(f"📥 Mensaje recibido: {mensaje}")
                break
            print(f"   Intento {i+1}/5...")
            import time
            time.sleep(1)
        
        ser.close()
        return True
        
    except Exception as e:
        print(f"❌ Error conectando a {puerto}: {e}")
        return False

if __name__ == "__main__":
    puertos = listar_puertos()
    
    if puertos:
        print("\n🎯 Probando conexiones...")
        for puerto in puertos:
            if probar_conexion(puerto):
                print(f"\n💡 Usa este puerto en config.py: PUERTO_SERIAL = '{puerto}'")
                break
    else:
        print("\n💡 Conecta el ESP32 y vuelve a ejecutar este script")