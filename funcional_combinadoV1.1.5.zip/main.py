from interfaz.ventana_principal import AfinadorGuitarraAcustica
import tkinter as tk
import serial
import threading
import time
from config import PUERTO_SERIAL, BAUDRATE

class ComunicacionSerial:
    def __init__(self, puerto=PUERTO_SERIAL, baudrate=BAUDRATE):
        self.puerto = puerto
        self.baudrate = baudrate
        self.serial_con = None
        self.conectado = False
        self.inicializar_serial()
    
    def inicializar_serial(self):
        try:
            self.serial_con = serial.Serial(self.puerto, self.baudrate, timeout=1)
            self.conectado = True
            print(f"✅ Conectado a {self.puerto}")
            time.sleep(2)  # Esperar inicialización del ESP32
        except Exception as e:
            print(f"❌ Error serial: {e}")
            print(f"   Intentando conectar a {self.puerto}")
            self.conectado = False
    
    def enviar_mensaje(self, tipo, linea1="", linea2="", linea3="", linea4=""):
        if self.conectado and self.serial_con:
            mensaje = f"{tipo},{linea1},{linea2},{linea3},{linea4}\n"
            try:
                self.serial_con.write(mensaje.encode('utf-8'))
                print(f"📤 Enviado: {mensaje.strip()}")
            except Exception as e:
                print(f"❌ Error enviando: {e}")
                self.conectado = False
        else:
            print(f"⚠️  No conectado, no se pudo enviar: {tipo},{linea1}")
    
    def leer_mensaje(self):
        if self.conectado and self.serial_con:
            try:
                if self.serial_con.in_waiting > 0:
                    linea = self.serial_con.readline().decode('utf-8').strip()
                    if linea:
                        print(f"📥 Recibido: {linea}")
                    return linea
            except Exception as e:
                print(f"❌ Error leyendo: {e}")
                self.conectado = False
        return None
    
    def cerrar(self):
        if self.serial_con and self.serial_con.is_open:
            self.serial_con.close()
            print("🔌 Conexión serial cerrada")

def hilo_serial(app):
    print("🔁 Iniciando hilo de comunicación serial...")
    while getattr(app, 'ejecutando', True):
        try:
            if hasattr(app, 'serial_com') and app.serial_com and app.serial_com.conectado:
                mensaje = app.serial_com.leer_mensaje()
                if mensaje:
                    print(f"🔍 RAW MENSAJE: '{mensaje}'")
                    procesar_comando_esp32(app, mensaje)
            time.sleep(0.1)
        except Exception as e:
            print(f"❌ Error en hilo serial: {e}")
            time.sleep(1)

def procesar_comando_esp32(app, mensaje):
    try:
        print(f"🔧 Procesando comando: {mensaje}")
        
        if mensaje.startswith("MODO_AFINADOR"):
            if hasattr(app, 'activar_modo_afinador'):
                app.activar_modo_afinador()
            if hasattr(app, 'serial_com') and app.serial_com:
                app.serial_com.enviar_mensaje('A', "Modo Afinador", "Listo", "Presiona A para", "capturar")
            
        elif mensaje.startswith("MODO_EFECTOS"):
            if hasattr(app, 'activar_modo_efectos'):
                app.activar_modo_efectos()
            if hasattr(app, 'serial_com') and app.serial_com:
                app.serial_com.enviar_mensaje('E', "Modo Efectos", "Listo", "Presiona A para", "grabar audio")
            
        elif mensaje.startswith("VOLVER_MENU"):
            if hasattr(app, 'activar_modo_afinador'):
                app.activar_modo_afinador()
            if hasattr(app, 'serial_com') and app.serial_com:
                app.serial_com.enviar_mensaje('A', "Menu Principal", "Selecciona modo", "A: Afinador", "B: Efectos")
            
        elif mensaje.startswith("INICIAR_AFINADOR"):
            if hasattr(app, 'escuchando'):
                if not app.escuchando:
                    app.toggle_captura()
                    if hasattr(app, 'serial_com') and app.serial_com:
                        app.serial_com.enviar_mensaje('A', "Capturando...", "Toca una cuerda", "de guitarra", "")
                else:
                    if hasattr(app, 'serial_com') and app.serial_com:
                        app.serial_com.enviar_mensaje('A', "Ya capturando", "Esperando señal", "de guitarra", "")
                
        elif mensaje.startswith("DETENER_AFINADOR"):
            if hasattr(app, 'escuchando') and app.escuchando:
                app.toggle_captura()
                if hasattr(app, 'serial_com') and app.serial_com:
                    app.serial_com.enviar_mensaje('A', "Captura detenida", "Presiona A para", "reanudar", "")
                
        elif mensaje.startswith("INICIAR_GRABACION"):
            if hasattr(app, 'procesador_efectos'):
                def grabar_async():
                    try:
                        print("🎙️ Iniciando grabación desde ESP32...")
                        # GRABAR Y ACTUALIZAR INTERFAZ
                        audio = app.procesador_efectos.grabar_audio()
                        
                        if hasattr(app, 'serial_com') and app.serial_com:
                            app.serial_com.enviar_mensaje('E', "Grabacion", "completada", "Listo para", "efectos")
                        
                        # ACTUALIZAR INTERFAZ MANUALMENTE POR SI ACASO
                        if hasattr(app, 'modo_actual') and app.modo_actual == "efectos":
                            if hasattr(app, 'panel_efectos'):
                                app.panel_efectos.lbl_estado_grabacion.config(text="Grabación completada")
                                if audio is not None and len(audio) > 0:
                                    app.panel_efectos.actualizar_grafica_audio(app.panel_efectos.ax_original, audio, "Audio Original")
                                print("✅ Interfaz actualizada manualmente después de grabación desde ESP32")
                                
                    except Exception as e:
                        print(f"❌ Error en grabación desde ESP32: {e}")
                        if hasattr(app, 'serial_com') and app.serial_com:
                            app.serial_com.enviar_mensaje('E', "Error", "Grabacion fallo", "Intente de nuevo", "")
                
                threading.Thread(target=grabar_async, daemon=True).start()
                if hasattr(app, 'serial_com') and app.serial_com:
                    app.serial_com.enviar_mensaje('E', "Grabando", "3 segundos...", "Toca o habla", "al microfono")
                
        elif mensaje.startswith("APLICAR_EFECTO"):
            if hasattr(app, 'procesador_efectos') and app.procesador_efectos.audio_original is not None:
                efecto = getattr(app, 'efecto_actual', 'Filtro Pasa-Bajos')
                intensidad = getattr(app, 'intensidad_actual', 50)
                
                print(f"🎛️ Aplicando efecto desde ESP32: {efecto} con intensidad {intensidad}%")
                
                # APLICAR EFECTO Y ACTUALIZAR INTERFAZ
                try:
                    audio_procesado = app.procesador_efectos.aplicar_efecto(efecto, intensidad)
                    
                    if hasattr(app, 'serial_com') and app.serial_com:
                        app.serial_com.enviar_mensaje('E', "Efecto aplicado", "Exitosamente", "Listo para", "reproducir")
                    
                    # ACTUALIZAR INTERFAZ MANUALMENTE POR SI ACASO
                    if hasattr(app, 'modo_actual') and app.modo_actual == "efectos":
                        if hasattr(app, 'panel_efectos'):
                            app.panel_efectos.lbl_estado_grabacion.config(text=f"Efecto aplicado: {efecto}")
                            if audio_procesado is not None and len(audio_procesado) > 0:
                                app.panel_efectos.actualizar_grafica_audio(app.panel_efectos.ax_efecto, audio_procesado, f"Audio con {efecto}")
                            print(f"✅ Interfaz actualizada manualmente después de efecto desde ESP32: {efecto}")
                            
                except Exception as e:
                    print(f"❌ Error aplicando efecto desde ESP32: {e}")
                    if hasattr(app, 'serial_com') and app.serial_com:
                        app.serial_com.enviar_mensaje('E', "Error", "Aplicar efecto", "fallo", str(e))
                        
            else:
                print("⚠️ No hay audio grabado para aplicar efecto")
                if hasattr(app, 'serial_com') and app.serial_com:
                    app.serial_com.enviar_mensaje('E', "Error", "No hay audio", "grabado", "")
                
        elif mensaje.startswith("REPRODUCIR_CON_EFECTO"):
            if hasattr(app, 'procesador_efectos'):
                try:
                    app.procesador_efectos.reproducir_procesado()
                    efecto = getattr(app, 'efecto_actual', 'Efecto')
                    if hasattr(app, 'serial_com') and app.serial_com:
                        app.serial_com.enviar_mensaje('E', "Reproduciendo", "Audio con efecto", efecto, "")
                    print(f"▶️ Reproduciendo audio con efecto: {efecto}")
                except Exception as e:
                    print(f"❌ Error reproduciendo con efecto: {e}")
                
        elif mensaje.startswith("REPRODUCIR_SIN_EFECTO"):
            if hasattr(app, 'procesador_efectos'):
                try:
                    app.procesador_efectos.reproducir_original()
                    if hasattr(app, 'serial_com') and app.serial_com:
                        app.serial_com.enviar_mensaje('E', "Reproduciendo", "Audio original", "", "")
                    print("▶️ Reproduciendo audio original")
                except Exception as e:
                    print(f"❌ Error reproduciendo sin efecto: {e}")
                
        elif mensaje.startswith("EFECTO_ACTUAL:"):
            efecto = mensaje.split(":")[1].strip()
            print(f"🎛️ Efecto recibido del ESP32: {efecto}")
            
            # Actualizar variable en la app
            app.efecto_actual = efecto
            
            # Sincronizar con el panel de efectos si está activo
            if hasattr(app, 'modo_actual') and app.modo_actual == "efectos":
                if hasattr(app, 'panel_efectos'):
                    app.panel_efectos.sincronizar_efecto_desde_serial(efecto)
            
            # Enviar confirmación al ESP32
            if hasattr(app, 'serial_com') and app.serial_com:
                app.serial_com.enviar_mensaje('E', efecto, "Seleccionado", "Listo para usar", "")
            
        elif mensaje.startswith("VOLUMEN:"):
            volumen = int(mensaje.split(":")[1])
            print(f"🔊 Volumen recibido: {volumen}%")
            
        elif mensaje.startswith("GRABAR_DE_NUEVO"):
            if hasattr(app, 'procesador_efectos'):
                app.procesador_efectos.audio_original = None
                app.procesador_efectos.audio_procesado = None
                if hasattr(app, 'serial_com') and app.serial_com:
                    app.serial_com.enviar_mensaje('E', "Listo para", "grabar nuevo", "audio", "")
                print("🔄 Preparado para grabar nuevo audio")
                
        elif mensaje.startswith("ESP32_INICIADO"):
            if hasattr(app, 'serial_com') and app.serial_com:
                app.serial_com.enviar_mensaje('A', "Python Conectado", "Sistema A.M.I", "Listo", "")
            print("🔄 ESP32 reiniciado/reconectado")
            
        elif mensaje.startswith("CANCELAR_GRABACION"):
            if hasattr(app, 'procesador_efectos'):
                app.procesador_efectos.audio_original = None
                app.procesador_efectos.audio_procesado = None
                if hasattr(app, 'serial_com') and app.serial_com:
                    app.serial_com.enviar_mensaje('E', "Grabacion", "cancelada", "Listo para", "nueva grabacion")
                print("❌ Grabación cancelada desde ESP32")
            
    except Exception as e:
        print(f"❌ Error procesando comando ESP32: {e}")

if __name__ == "__main__":
    try:
        print("🎸 Iniciando Asistente Musical Inteligente...")
        
        main_root = tk.Tk()
        app = AfinadorGuitarraAcustica(main_root)
        
        # Inicializar comunicación serial
        print("🔌 Inicializando comunicación serial...")
        app.serial_com = ComunicacionSerial()
        app.ejecutando = True
        
        # Configurar variables para efectos
        app.efecto_actual = "Filtro Pasa-Bajos"
        app.intensidad_actual = 50
        
        # Pasar la comunicación serial al procesador de efectos
        if hasattr(app, 'procesador_efectos') and app.serial_com:
            app.procesador_efectos.serial_com = app.serial_com
        
        # CONFIGURAR CALLBACK EN PROCESADOR DE EFECTOS
        if hasattr(app, 'procesador_efectos') and hasattr(app, 'actualizar_interfaz_efectos'):
            app.procesador_efectos.set_callback_actualizacion(app.actualizar_interfaz_efectos)
            print("✅ Callback de actualización configurado en procesador de efectos")
        
        # Iniciar hilo para comunicación serial solo si está conectado
        if app.serial_com and app.serial_com.conectado:
            hilo = threading.Thread(target=hilo_serial, args=(app,), daemon=True)
            hilo.start()
            print("✅ Hilo de comunicación serial iniciado")
            
            # Enviar mensaje de inicialización al ESP32
            time.sleep(1)
            app.serial_com.enviar_mensaje('A', "Sistema A.M.I", "Python Conectado", "Listo para usar", "")
        else:
            print("⚠️  No se pudo conectar al ESP32, continuando sin comunicación serial")
        
        def on_closing():
            print("🔴 Cerrando aplicación...")
            app.ejecutando = False
            if hasattr(app, 'serial_com') and app.serial_com:
                app.serial_com.cerrar()
            app.cerrar_aplicacion()
            
        main_root.protocol("WM_DELETE_WINDOW", on_closing)
        
        print("✅ Aplicación iniciada correctamente")
        print("=" * 50)
        print("🎮 CONTROLES DISPONIBLES:")
        print("   - Interfaz gráfica: Botones y menús")
        print("   - ESP32: Botones A, B, C, D")
        print("   - Modos: Afinador, Acordes, Espectro, Efectos")
        print("=" * 50)
        
        main_root.mainloop()
        
    except Exception as main_error:
        print(f"❌ Error crítico: {main_error}")
        import traceback
        traceback.print_exc()