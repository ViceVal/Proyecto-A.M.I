# --- PARÁMETROS MEJORADOS ---
FRECUENCIA_MUESTREO = 44100
TAMANO_BLOQUE = 4096
NPERSEG = 8192
NOVERLAP = 6144
UMBRAL_VOLUMEN = 0.001

# --- FRECUENCIAS DE NOTAS MUSICALES ---
NOTAS_MUSICALES = {
    "C": 130.81,   "C#": 138.59,  "D": 146.83,   "D#": 155.56,
    "E": 164.81,   "F": 174.61,   "F#": 185.00,  "G": 196.00,
    "G#": 207.65,  "A": 220.00,   "A#": 233.08,  "B": 246.94,
}

# --- FRECUENCIAS EMPÍRICAS CALIBRADAS ---
CUERDAS_GUITARRA = {
    "E2": (161.5, 150, 175),   # E2 empirico- 6ta cuerda
    "A2": (220.7, 200, 240), # A2 empirico - 5ta cuerda  
    "D3": (146.83, 130, 160), # D3 - 4ta cuerda
    "G3": (196.00, 180, 210), # G3 - 3ra cuerda
    "B3": (246.94, 230, 260), # B3 - 2da cuerda
    "E4": (329.63, 300, 350)  # E4 - 1ra cuerda
}

# --- SISTEMA DE ACORDES MEJORADO ---
ACORDES_GUITARRA = {
    # Acordes mayores
    "E Mayor": {"notas": ["E", "G#", "B"], "tipo": "mayor", "prioridad": 1},
    "A Mayor": {"notas": ["A", "C#", "E"], "tipo": "mayor", "prioridad": 1},
    "D Mayor": {"notas": ["D", "F#", "A"], "tipo": "mayor", "prioridad": 1},
    "G Mayor": {"notas": ["G", "B", "D"], "tipo": "mayor", "prioridad": 1},
    "C Mayor": {"notas": ["C", "E", "G"], "tipo": "mayor", "prioridad": 1},
    "F Mayor": {"notas": ["F", "A", "C"], "tipo": "mayor", "prioridad": 1},
    "B Mayor": {"notas": ["B", "D#", "F#"], "tipo": "mayor", "prioridad": 1},
    
    # Acordes menores
    "E menor": {"notas": ["E", "G", "B"], "tipo": "menor", "prioridad": 1},
    "A menor": {"notas": ["A", "C", "E"], "tipo": "menor", "prioridad": 1},
    "D menor": {"notas": ["D", "F", "A"], "tipo": "menor", "prioridad": 1},
    "G menor": {"notas": ["G", "A#", "D"], "tipo": "menor", "prioridad": 1},
    "C menor": {"notas": ["C", "D#", "G"], "tipo": "menor", "prioridad": 1},
    "F menor": {"notas": ["F", "G#", "C"], "tipo": "menor", "prioridad": 1},
    "B menor": {"notas": ["B", "D", "F#"], "tipo": "menor", "prioridad": 1},
}

# --- CONFIGURACIÓN SERIAL PARA ESP32 ---
# PUERTO_SERIAL = 'COM3'  # Windows
# PUERTO_SERIAL = '/dev/ttyUSB0'  # Linux
# PUERTO_SERIAL = '/dev/cu.usbserial-*'  # Mac

# Lista de puertos a probar (en orden de prioridad)
PUERTOS_POSIBLES = [
    'COM3', 'COM4', 'COM5', 'COM6',  # Windows
    '/dev/ttyUSB0', '/dev/ttyUSB1',   # Linux
    '/dev/ttyACM0', '/dev/ttyACM1',   # Linux (Arduino)
]

# Usar el primer puerto disponible
PUERTO_SERIAL = 'COM5'  # Cambia este índice según tu sistema
BAUDRATE = 115200