import numpy as np
import math
from typing import Dict, Any, List
from config import FRECUENCIA_MUESTREO

class AnalizadorFourier:
    """Implementa las Series de Fourier: f(t) = a0 + Σ [an cos(nω0t) + bn sin(nω0t)]"""
    def __init__(self):
        self.num_armonicos = 10
        
    def calcular_series_fourier(self, audio_data: np.ndarray, frecuencia_fundamental: float) -> Dict[str, Any]:
        """Calcula los coeficientes de Fourier para una señal"""
        try:
            N = len(audio_data)
            if N == 0:
                return {}
            
            T = N / FRECUENCIA_MUESTREO
            t = np.linspace(0, T, N, endpoint=False)
            omega_0 = 2 * math.pi * frecuencia_fundamental
            a0 = np.mean(audio_data)
            
            # CORRECCIÓN: Crear listas explícitas primero y luego asignarlas al diccionario
            a_n_list: List[float] = []
            b_n_list: List[float] = []
            armonicos_list: List[int] = []
            magnitudes_list: List[float] = []
            
            for n in range(1, self.num_armonicos + 1):
                assert audio_data is not None
                audio_float = audio_data.astype(np.float64)
                t_float = t.astype(np.float64)
                cos_term_float = np.cos(n * omega_0 * t_float).astype(np.float64)
                sin_term_float = np.sin(n * omega_0 * t_float).astype(np.float64)
                
                an_val = (2.0 / T) * np.trapezoid(audio_float * cos_term_float, t_float)
                bn_val = (2.0 / T) * np.trapezoid(audio_float * sin_term_float, t_float)
                magnitud = math.sqrt(float(an_val)**2 + float(bn_val)**2)
                
                a_n_list.append(float(an_val))
                b_n_list.append(float(bn_val))
                armonicos_list.append(int(n))
                magnitudes_list.append(float(magnitud))
            
            # Ahora crear el diccionario con las listas ya pobladas
            coeficientes: Dict[str, Any] = {
                'a0': float(a0),
                'a_n': a_n_list,
                'b_n': b_n_list,
                'armonicos': armonicos_list,
                'magnitudes': magnitudes_list,
                'frecuencia_fundamental': frecuencia_fundamental
            }
            
            return coeficientes
            
        except Exception as error:
            print(f"Error en series de Fourier: {error}")
            return {}
    
    def analizar_timbre(self, coeficientes: Dict[str, Any]) -> Dict[str, float]:
        """Analiza el timbre basado en la distribución de armónicos (EXACTO COMO ACORDESPRECISO)"""
        try:
            if not coeficientes or 'magnitudes' not in coeficientes:
                return {}
            
            magnitudes = coeficientes['magnitudes']
            if not magnitudes:
                return {}
            # CORRECCIÓN: Especificar explícitamente el tipo dtype
            magnitudes_arr: np.ndarray = np.array(magnitudes, dtype=np.float64)
            
            magnitud_fundamental = magnitudes_arr[0] if len(magnitudes_arr) > 0 else 0.0
            magnitud_total = np.sum(magnitudes_arr)
            
            if magnitud_total == 0:
                return {}
            
            # Relación armónica (riqueza espectral) - PARÁMETROS EXACTOS DE ACORDESPRECISO
            relacion_armonicos = np.sum(magnitudes_arr[1:5]) / magnitud_total if magnitud_total > 0 else 0.0
            
            # Ancho de banda espectral (armónico más significativo)
            armonico_max = int(np.argmax(magnitudes_arr)) + 1 if len(magnitudes_arr) > 0 else 1
            
            return {
                'riqueza_espectral': float(relacion_armonicos),
                'armonico_principal': int(armonico_max),
                'relacion_fundamental': float(magnitud_fundamental / magnitud_total if magnitud_total > 0 else 0.0),
                'brillantez': float(np.sum(magnitudes_arr[3:]) / magnitud_total if magnitud_total > 0 else 0.0)
            }
            
        except Exception as error:
            print(f"Error analizando timbre: {error}")
            return {}