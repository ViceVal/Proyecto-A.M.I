import numpy as np
import sounddevice as sd
import soundfile as sf
from scipy.signal import butter, lfilter, fftconvolve
from typing import Optional

from config import FRECUENCIA_MUESTREO

class ProcesadorEfectos:
    """Procesador de efectos de audio para la pedalera"""
    def __init__(self, serial_com=None):
        self.samplerate = FRECUENCIA_MUESTREO
        self.audio_original: Optional[np.ndarray] = None
        self.audio_procesado: Optional[np.ndarray] = None
        self.grabando = False
        self.grabacion_actual: Optional[np.ndarray] = None
        self.serial_com = serial_com
        self.callback_actualizacion = None  # Nuevo: callback para actualizar UI
    
    def set_callback_actualizacion(self, callback):
        """Establece un callback para actualizar la interfaz"""
        self.callback_actualizacion = callback
    
    def grabar_audio(self, duracion: float = 3.0) -> np.ndarray:
        """Graba audio desde el micrófono"""
        print(f"Grabando {duracion} segundos...")
        
        # NOTIFICAR INICIO DE GRABACIÓN AL ESP32
        if self.serial_com and self.serial_com.conectado:
            self.serial_com.enviar_mensaje('E', "Grabando", "3 segundos", "Por favor espere", "")
        
        self.grabando = True
        grabacion_samples = int(duracion * self.samplerate)

        self.grabacion_actual = sd.rec(grabacion_samples, 
                                  samplerate=self.samplerate, 
                                  channels=1, dtype=np.float64)
        sd.wait()
        self.grabando = False

        # CORRECCIÓN: Verificación única y explícita
        if (self.grabacion_actual is None or 
            len(self.grabacion_actual) == 0 or 
            np.max(np.abs(self.grabacion_actual)) == 0):
            print("Error: No se pudo grabar audio válido")
            
            # NOTIFICAR ERROR AL ESP32
            if self.serial_com and self.serial_com.conectado:
                self.serial_com.enviar_mensaje('E', "Error", "Grabacion fallo", "Intente de nuevo", "")
                
            return np.array([], dtype=np.float64)

        # CORRECCIÓN: Aplanar y convertir - sabemos que no es None aquí
        audio_data = self.grabacion_actual.flatten().astype(np.float64)

        # Normalizar
        max_val = np.max(np.abs(audio_data))
        if max_val > 0:
            audio_data = (audio_data / max_val).astype(np.float64)

        self.audio_original = audio_data
        print("Grabación completada")
        
        # NOTIFICAR GRABACIÓN COMPLETADA AL ESP32
        if self.serial_com and self.serial_com.conectado:
            self.serial_com.enviar_mensaje('E', "Grabacion", "completada", "Listo para", "efectos")
        
        # ACTUALIZAR INTERFAZ GRÁFICA
        if self.callback_actualizacion:
            self.callback_actualizacion('grabacion_completada', self.audio_original)
            
        return self.audio_original
    
    def aplicar_efecto(self, efecto: str, parametro: float) -> np.ndarray:
        """Aplica efecto al audio grabado"""
        if self.audio_original is None:
            raise ValueError("No hay audio grabado para procesar")
            
        audio = self.audio_original.copy()
        val = parametro / 100.0
        resultado: np.ndarray = audio.astype(np.float64)

        if "Pasa-Bajos" in efecto:
            cutoff = 500 + (val * 4000)
            nyq = 0.5 * self.samplerate
            normal_cutoff = cutoff / nyq
            b, a = butter(5, normal_cutoff, btype='low', analog=False)
            resultado_temp = lfilter(b, a, audio)
            resultado = resultado_temp.astype(np.float64)

        elif "Distorsión" in efecto:
            drive = 1 + (val * 20)
            resultado = np.tanh(audio * drive).astype(np.float64)
            if np.max(np.abs(resultado)) > 0:
                resultado = (resultado / np.max(np.abs(resultado))).astype(np.float64)

        elif "Modulación" in efecto:
            freq_mod = 5 + (val * 500)
            t_mod = np.arange(len(audio)) / self.samplerate
            carrier = np.sin(2 * np.pi * freq_mod * t_mod)
            resultado = ((audio * 0.5) + ((audio * carrier) * 0.5)).astype(np.float64)

        elif "Delay" in efecto:
            delay_sec = 0.1 + (val * 0.8)
            delay_samples = int(delay_sec * self.samplerate)
            decay = 0.5
            output = np.zeros(len(audio) + delay_samples, dtype=np.float64)
            output[:len(audio)] += audio
            output[delay_samples:] += audio * decay
            resultado = output

        elif "Reverb" in efecto:
            reverb_len = int(self.samplerate * (0.5 + val * 2.0))
            t_reverb: np.ndarray = np.linspace(0, 1, reverb_len, dtype=np.float64)
            ir = np.random.randn(reverb_len).astype(np.float64) * np.exp(-5 * t_reverb)
            resultado_temp = fftconvolve(audio, ir, mode='full')
            resultado = resultado_temp.astype(np.float64)
            if np.max(np.abs(resultado)) > 0:
                max_val = np.max(np.abs(resultado))
                resultado = resultado / max_val
                resultado = (resultado * 0.9).astype(np.float64)

        self.audio_procesado = resultado
        
        # NOTIFICAR APLICACIÓN DE EFECTO AL ESP32
        if self.serial_com and self.serial_com.conectado:
            self.serial_com.enviar_mensaje('E', efecto, "Aplicado", f"Intensidad: {parametro}%", "Listo")
        
        # ACTUALIZAR INTERFAZ GRÁFICA
        if self.callback_actualizacion:
            self.callback_actualizacion('efecto_aplicado', self.audio_procesado, efecto)
            
        return self.audio_procesado
    
    def reproducir_original(self):
        """Reproduce el audio original"""
        if self.audio_original is not None:
            sd.stop()
            sd.play(self.audio_original, self.samplerate)
            
            # NOTIFICAR REPRODUCCIÓN AL ESP32
            if self.serial_com and self.serial_com.conectado:
                self.serial_com.enviar_mensaje('E', "Reproduciendo", "Audio original", "", "")
    
    def reproducir_procesado(self):
        """Reproduce el audio procesado"""
        if self.audio_procesado is not None:
            sd.stop()
            sd.play(self.audio_procesado, self.samplerate)
            
            # NOTIFICAR REPRODUCCIÓN AL ESP32
            if self.serial_com and self.serial_com.conectado:
                self.serial_com.enviar_mensaje('E', "Reproduciendo", "Audio con efecto", "", "")
    
    def guardar_audio(self, archivo: str, audio_data: np.ndarray):
        """Guarda el audio en un archivo"""
        if audio_data is not None:
            sf.write(archivo, audio_data, self.samplerate)
            
            # NOTIFICAR GUARDADO AL ESP32
            if self.serial_com and self.serial_com.conectado:
                self.serial_com.enviar_mensaje('E', "Audio guardado", f"Archivo: {archivo}", "", "")