import numpy as np
import math
from collections import deque, Counter
from typing import Optional, Tuple, Deque
from scipy.signal import find_peaks

from config import CUERDAS_GUITARRA
from procesadores.detector_notas import DetectorNotasAcordes

class ProcesadorGuitarraAcustica:
    def __init__(self, serial_com=None):
        self.historico_fundamentales: Deque[float] = deque(maxlen=5)
        self.historico_cuerdas: Deque[str] = deque(maxlen=5)
        self.detector_notas = DetectorNotasAcordes()
        self.serial_com = serial_com  # Nueva línea para comunicación serial
        
    def detectar_fundamental_segura(self, audio_data: np.ndarray) -> Tuple[Optional[float], Optional[str]]:
        """Detección robusta de fundamental - AHORA CON FOURIER (EXACTO COMO ACORDESPRECISO)"""
        try:
            f, magnitudes = self.detector_notas.calcular_espectro_mejorado(audio_data)
            
            if len(f) == 0 or len(magnitudes) == 0:
                return None, None
            
            mascara = (f >= 90) & (f <= 380)
            if not np.any(mascara):
                return None, None
                
            f_guitarra = f[mascara]
            mag_guitarra = magnitudes[mascara]
            
            altura_minima = 0.05 * np.max(mag_guitarra)
            
            if len(mag_guitarra) < 3:
                return None, None
                
            picos, propiedades = find_peaks(mag_guitarra, 
                                          height=altura_minima,
                                          distance=3,
                                          prominence=altura_minima*0.3)
            
            if len(picos) == 0:
                return None, None
            
            if 'peak_heights' in propiedades and len(propiedades['peak_heights']) > 0:
                idx_principal = picos[np.argmax(propiedades['peak_heights'])]
                if idx_principal < len(f_guitarra):
                    frecuencia = float(f_guitarra[idx_principal])
                    cuerda = self.identificar_cuerda_segura(frecuencia)
                    return frecuencia, cuerda
                    
        except Exception as error:
            print(f"Error en detección fundamental: {error}")
            
        return None, None
    
    def identificar_cuerda_segura(self, frecuencia: float) -> Optional[str]:
        """Identificación de cuerda basada en frecuencias empíricas)"""
        try:
            mejor_cuerda: Optional[str] = None
            menor_distancia: float = float('inf')
            
            for cuerda, (freq_objetivo, min_freq, max_freq) in CUERDAS_GUITARRA.items():
                if min_freq <= frecuencia <= max_freq:
                    distancia = abs(math.log2(frecuencia / freq_objetivo))
                    if distancia < menor_distancia:
                        menor_distancia = distancia
                        mejor_cuerda = cuerda
            
            if mejor_cuerda is None:
                for cuerda, (freq_objetivo, _, _) in CUERDAS_GUITARRA.items():
                    if frecuencia > 0:
                        distancia = abs(math.log2(frecuencia / freq_objetivo))
                        if distancia < menor_distancia:
                            menor_distancia = distancia
                            mejor_cuerda = cuerda
                            
            return mejor_cuerda
        except Exception:
            return None
    
    def procesar_estabilidad_segura(self, frecuencia: Optional[float], cuerda: Optional[str]) -> Tuple[Optional[float], Optional[str]]:
        """Filtrado de estabilidad)"""
        try:
            if frecuencia and cuerda:
                self.historico_fundamentales.append(frecuencia)
                self.historico_cuerdas.append(cuerda)
                
                if len(self.historico_fundamentales) >= 3:
                    conteo = Counter(self.historico_cuerdas)
                    if conteo:
                        cuerda_estable, count = conteo.most_common(1)[0]
                        
                        if count >= len(self.historico_cuerdas) * 0.6:
                            frecuencias_filtradas = [
                                f for f, c in zip(self.historico_fundamentales, self.historico_cuerdas)
                                if c == cuerda_estable
                            ]
                            
                            if frecuencias_filtradas:
                                frecuencia_estable = float(np.median(frecuencias_filtradas))
                                return frecuencia_estable, cuerda_estable
                                
        except Exception as error:
            print(f"Error en estabilidad: {error}")
            
        return frecuencia, cuerda

    def detectar_acorde_completo(self, audio_data: np.ndarray) -> Tuple[str, str]:
        """Detección completa de acorde usando sistema MEJORADO con Fourier"""
        notas_detectadas = self.detector_notas.detectar_notas_en_audio(audio_data)
        return self.detector_notas.identificar_acorde_por_notas(notas_detectadas)