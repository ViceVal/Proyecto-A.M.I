import numpy as np
import math
import time
from collections import deque, Counter
from typing import Dict, Any, List, Tuple, Optional, Deque
from scipy.signal import stft, find_peaks

from config import FRECUENCIA_MUESTREO, NPERSEG, NOVERLAP, NOTAS_MUSICALES, ACORDES_GUITARRA
from procesadores.fourier import AnalizadorFourier

class DetectorNotasAcordes:
    def __init__(self):
        self.historico_acordes: Deque[str] = deque(maxlen=5)
        self.historico_notas: Deque[str] = deque(maxlen=10)
        self.ultimo_acorde_detectado: Optional[str] = None
        self.tiempo_ultimo_acorde: float = 0.0
        self.analizador_fourier = AnalizadorFourier()
        
    def frecuencia_a_nota(self, frecuencia: float) -> Tuple[Optional[str], float]:
        """Convierte frecuencia a nota musical más cercana (EXACTO COMO ACORDESPRECISO)"""
        mejor_nota: Optional[str] = None
        menor_error: float = float('inf')
        
        for nota, freq_objetivo in NOTAS_MUSICALES.items():
            for octava in range(2, 6):
                freq_octava = freq_objetivo * (2 ** (octava - 4))
                error = abs(math.log2(frecuencia / freq_octava))
                if error < menor_error:
                    menor_error = error
                    mejor_nota = nota
        
        return mejor_nota, menor_error

    def calcular_espectro_mejorado(self, audio_data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """STFT optimizado - PARÁMETROS EXACTOS DE ACORDESPRECISO"""
        try:
            if len(audio_data) < NPERSEG:
                audio_data = np.pad(audio_data, (0, NPERSEG - len(audio_data)), mode='constant')
            
            f, _, Zxx = stft(audio_data, 
                            fs=FRECUENCIA_MUESTREO,
                            nperseg=NPERSEG,
                            noverlap=NOVERLAP,
                            window='hann',
                            nfft=NPERSEG * 2)
            
            magnitudes = np.sqrt(np.mean(np.abs(Zxx)**2, axis=1))
            return f, magnitudes
            
        except Exception as error:
            print(f"Error en cálculo de espectro: {error}")
            return np.array([]), np.array([])

    def detectar_notas_en_audio(self, audio_data: np.ndarray) -> List[Dict[str, Any]]:
        """Detecta notas usando ANÁLISIS COMBINADO: STFT + Series de Fourier (EXACTO COMO ACORDESPRECISO)"""
        try:
            # PRIMERO: Detección tradicional con STFT
            f, magnitudes = self.calcular_espectro_mejorado(audio_data)
            
            if len(f) == 0 or len(magnitudes) == 0:
                return []
            
            notas_detectadas: List[Dict[str, Any]] = []
            
            umbral = 0.015 * np.max(magnitudes)
            picos, propiedades = find_peaks(magnitudes, 
                                          height=umbral, 
                                          distance=8,
                                          prominence=umbral*0.5)
            
            if len(picos) > 0 and 'peak_heights' in propiedades:
                for i, pico in enumerate(picos):
                    if pico < len(f):
                        freq = f[pico]
                        if 80 <= freq <= 450:
                            nota, error = self.frecuencia_a_nota(freq)
                            if nota and error < 0.08:
                                magnitud = propiedades['peak_heights'][i]
                                if magnitud > umbral * 1.2:
                                    
                                    # SEGUNDO: ANÁLISIS CON SERIES DE FOURIER
                                    coeficientes_fourier = self.analizador_fourier.calcular_series_fourier(
                                        audio_data, freq
                                    )
                                    
                                    analisis_timbre = self.analizador_fourier.analizar_timbre(coeficientes_fourier)
                                    
                                    notas_detectadas.append({
                                        'nota': nota,
                                        'frecuencia': freq,
                                        'error': error,
                                        'magnitud': magnitud,
                                        'coeficientes_fourier': coeficientes_fourier,
                                        'timbre': analisis_timbre,
                                        'confianza': self.calcular_confianza(analisis_timbre, error)
                                    })
            
            # Ordenar por confianza (nuevo criterio)
            notas_detectadas.sort(key=lambda x: x['confianza'], reverse=True)
            
            # Eliminar duplicados
            notas_unicas: Dict[str, Dict[str, Any]] = {}
            for nota_info in notas_detectadas:
                nota = nota_info['nota']
                if nota is not None:
                    if nota not in notas_unicas or nota_info['confianza'] > notas_unicas[nota]['confianza']:
                        notas_unicas[nota] = nota_info
            
            return list(notas_unicas.values())
            
        except Exception as error:
            print(f"Error detectando notas: {error}")
            return []

    def calcular_confianza(self, timbre: Dict[str, float], error_frecuencia: float) -> float:
        """Calcula confianza basada en análisis de Fourier (EXACTO COMO ACORDESPRECISO)"""
        confianza = 1.0 - min(error_frecuencia * 10, 1.0)  # Base por error de frecuencia
        
        # Mejorar confianza si el timbre es consistente con instrumento de cuerda
        if timbre:
            # Cuerdas típicamente tienen armónicos fuertes
            if timbre.get('riqueza_espectral', 0) > 0.3:
                confianza += 0.2
            # Fundamental debería ser dominante
            if timbre.get('relacion_fundamental', 0) > 0.4:
                confianza += 0.1
        
        return min(confianza, 1.0)

    def identificar_acorde_por_notas(self, notas_detectadas: List[Dict[str, Any]]) -> Tuple[str, str]:
        """Identifica acordes con ANÁLISIS MEJORADO usando información de Fourier (EXACTO COMO ACORDESPRECISO)"""
        if len(notas_detectadas) < 2:
            return "No detectado", "Muy pocas notas"
        
        # Extraer información mejorada
        notas_completas: List[str] = []
        info_fourier = []
        
        for nota_info in notas_detectadas:
            nota = nota_info['nota']
            if nota is not None:
                notas_completas.append(nota)
                info_fourier.append({
                    'nota': nota,
                    'frecuencia': nota_info['frecuencia'],
                    'confianza': nota_info.get('confianza', 0.5),
                    'timbre': nota_info.get('timbre', {})
                })
        
        if not notas_completas:
            return "No detectado", "No se detectaron notas válidas"
        
        notas_set = set(notas_completas)
        print(f"Notas detectadas: {notas_set}")
        
        fourier_info_str = ", ".join([f"{n['nota']}({n['confianza']:.2f})" for n in info_fourier])
        print(f"Análisis Fourier: {fourier_info_str}")
        
        mejor_acorde: Optional[str] = None
        mejor_puntaje: float = 0.0
        
        tonica_probable = self.identificar_tonica_probable(notas_completas)
        print(f"Tónica probable: {tonica_probable}")
        
        for acorde, info in ACORDES_GUITARRA.items():
            # Puntaje base por coincidencia de notas
            notas_acorde_set = set(info["notas"])
            coincidencias_exactas = notas_set.intersection(notas_acorde_set)
            puntaje_exacto = len(coincidencias_exactas) / len(info["notas"])
            
            # Considerar notas base
            notas_base_detectadas = set([n[0] for n in notas_completas])
            notas_base_acorde = set([n[0] for n in info["notas"]])
            coincidencias_base = notas_base_detectadas.intersection(notas_base_acorde)
            puntaje_base = len(coincidencias_base) / len(info["notas"])
            
            puntaje = (puntaje_exacto * 0.7) + (puntaje_base * 0.3)
            
            # BONUS MEJORADO: Usar información de Fourier para confianza
            tonica_acorde = info["notas"][0]
            if tonica_acorde in notas_set:
                # Buscar la tónica en info_fourier para ver su confianza
                for nota_info in info_fourier:
                    if nota_info['nota'] == tonica_acorde:
                        puntaje += 0.3 + (0.2 * nota_info['confianza'])  # Bonus variable por confianza
                        break
            elif tonica_acorde[0] in notas_base_detectadas and tonica_probable == tonica_acorde[0]:
                puntaje += 0.2
            
            # Bonus por tercera con confianza
            tercera_acorde = info["notas"][1]
            if tercera_acorde in notas_set:
                for nota_info in info_fourier:
                    if nota_info['nota'] == tercera_acorde:
                        puntaje += 0.3 + (0.1 * nota_info['confianza'])
                        break
            
            # Bonus por quinta
            quinta_acorde = info["notas"][2]
            if quinta_acorde in notas_set:
                puntaje += 0.2
            
            # Penalizaciones específicas para diferenciar mayores y menores
            puntaje = self.aplicar_penalizaciones_especificas(puntaje, acorde, notas_set)
            
            print(f"  {acorde}: exactas={coincidencias_exactas} ({puntaje:.1%})")
            
            if puntaje > mejor_puntaje:
                mejor_puntaje = puntaje
                mejor_acorde = acorde
        
        # Lógica de histórico mejorada
        tiempo_actual = time.time()
        if mejor_acorde and mejor_puntaje > 0.7:
            self.ultimo_acorde_detectado = mejor_acorde
            self.tiempo_ultimo_acorde = tiempo_actual
            self.historico_acordes.append(mejor_acorde)
            
            if len(self.historico_acordes) >= 3:
                conteo = Counter(self.historico_acordes)
                acorde_estable, count = conteo.most_common(1)[0]
                if count >= 2:
                    return acorde_estable, f"✅ {acorde_estable} ({mejor_puntaje:.0%})"
            
            if mejor_puntaje > 0.85:
                return mejor_acorde, f"🎵 {mejor_acorde} ({mejor_puntaje:.0%})"
            elif mejor_puntaje > 0.75:
                return f"Posible {mejor_acorde}", f"{mejor_puntaje:.0%} coincidencia"
        
        elif (self.ultimo_acorde_detectado and 
              tiempo_actual - self.tiempo_ultimo_acorde < 2.0):
            return self.ultimo_acorde_detectado, f"⏹ {self.ultimo_acorde_detectado} (mantenido)"
        
        return "No identificado", f"Notas: {', '.join(notas_set)}"

    def aplicar_penalizaciones_especificas(self, puntaje: float, acorde: str, notas_set: set) -> float:
        """Aplica penalizaciones específicas para mejorar diferenciación mayores/menores"""
        # Penalizaciones exactas de acordespreciso.py
        if acorde == "B Mayor" and "D" in notas_set and "D#" not in notas_set:
            puntaje -= 0.3
        elif acorde == "B menor" and "D#" in notas_set and "D" not in notas_set:
            puntaje -= 0.3
        elif acorde == "G Mayor" and "F#" in notas_set and len(notas_set) < 3:
            puntaje -= 0.2
        elif acorde == "A menor" and "C#" in notas_set:
            puntaje -= 0.4
        
        # Penalizaciones adicionales para mejorar diferenciación
        if "menor" in acorde:
            # Para acordes menores, penalizar si aparece la tercera mayor
            tonica = acorde.split(" ")[0]
            tercera_mayor = self.obtener_tercera_mayor(tonica)
            if tercera_mayor in notas_set:
                puntaje -= 0.3
        elif "Mayor" in acorde:
            # Para acordes mayores, penalizar si aparece la tercera menor
            tonica = acorde.split(" ")[0]
            tercera_menor = self.obtener_tercera_menor(tonica)
            if tercera_menor in notas_set:
                puntaje -= 0.3
        
        return max(puntaje, 0.0)

    def obtener_tercera_mayor(self, nota: str) -> str:
        """Obtiene la tercera mayor de una nota"""
        terceras_mayores = {
            "C": "E", "C#": "F", "D": "F#", "D#": "G", 
            "E": "G#", "F": "A", "F#": "A#", "G": "B", 
            "G#": "C", "A": "C#", "A#": "D", "B": "D#"
        }
        return terceras_mayores.get(nota, "")

    def obtener_tercera_menor(self, nota: str) -> str:
        """Obtiene la tercera menor de una nota"""
        terceras_menores = {
            "C": "D#", "C#": "E", "D": "F", "D#": "F#", 
            "E": "G", "F": "G#", "F#": "A", "G": "A#", 
            "G#": "B", "A": "C", "A#": "C#", "B": "D"
        }
        return terceras_menores.get(nota, "")

    def identificar_tonica_probable(self, notas: List[str]) -> str:
        """Identifica la tónica más probable basada en las notas detectadas (EXACTO COMO ACORDESPRECISO)"""
        if not notas:
            return ""
        
        notas_base = [n[0] for n in notas]
        conteo = Counter(notas_base)
        
        tonicas_comunes = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
        for tonica in tonicas_comunes:
            if tonica in conteo:
                return tonica
        
        return conteo.most_common(1)[0][0]