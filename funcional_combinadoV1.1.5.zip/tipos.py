from typing import TypedDict, List

class CoeficientesFourier(TypedDict):
    a0: float
    a_n: List[float]
    b_n: List[float]
    armonicos: List[int]
    magnitudes: List[float]
    frecuencia_fundamental: float