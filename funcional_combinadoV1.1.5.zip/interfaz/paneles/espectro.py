import tkinter as tk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from typing import TYPE_CHECKING, List, Dict, Any

if TYPE_CHECKING:
    from interfaz.ventana_principal import AfinadorGuitarraAcustica

class PanelEspectro:
    def __init__(self, parent, app: 'AfinadorGuitarraAcustica'):
        self.parent = parent
        self.app = app
        self.crear_interfaz()
    
    def crear_interfaz(self):
        self.frame_espectro = tk.Frame(self.parent, bg="#2c3e50", relief=tk.RAISED, bd=2)
        
        tk.Label(self.frame_espectro, 
                text="📈 VISUALIZADOR DE ESPECTRO + DETECTOR DE NOTAS/ACORDES", 
                font=("Arial", 14, "bold"),
                bg="#2c3e50", fg="white").pack(pady=15)
        
        # Información de detección musical
        info_musica_frame = tk.Frame(self.frame_espectro, bg="#2c3e50")
        info_musica_frame.pack(pady=10)
        
        # Acorde detectado
        self.lbl_acorde_espectro = tk.Label(info_musica_frame,
                                          text="Acorde: --",
                                          font=("Arial", 18, "bold"),
                                          bg="#2c3e50", fg="#ff9900")
        self.lbl_acorde_espectro.pack()
        
        # Información del acorde
        self.lbl_info_acorde_espectro = tk.Label(info_musica_frame,
                                               text="Información: --",
                                               font=("Arial", 12),
                                               bg="#2c3e50", fg="#cccccc")
        self.lbl_info_acorde_espectro.pack()
        
        # Notas detectadas
        self.lbl_notas_espectro = tk.Label(info_musica_frame,
                                         text="Notas detectadas: --",
                                         font=("Arial", 11),
                                         bg="#2c3e50", fg="#00ff88")
        self.lbl_notas_espectro.pack()
        
        # Frecuencia principal y volumen
        info_frecuencia_frame = tk.Frame(self.frame_espectro, bg="#2c3e50")
        info_frecuencia_frame.pack(pady=5)
        
        self.lbl_frecuencia_principal = tk.Label(info_frecuencia_frame,
                                               text="Frecuencia Principal: -- Hz",
                                               font=("Arial", 12),
                                               bg="#2c3e50", fg="#00ccff")
        self.lbl_frecuencia_principal.pack(side=tk.LEFT, padx=10)
        
        self.lbl_volumen = tk.Label(info_frecuencia_frame,
                                  text="Volumen: --",
                                  font=("Arial", 12),
                                  bg="#2c3e50", fg="#ff6666")
        self.lbl_volumen.pack(side=tk.LEFT, padx=10)
        
        # Estado de detección
        self.lbl_estado_deteccion = tk.Label(info_frecuencia_frame,
                                           text="Estado: Silencio",
                                           font=("Arial", 10),
                                           bg="#2c3e50", fg="#ffff00")
        self.lbl_estado_deteccion.pack(side=tk.LEFT, padx=10)
        
        # Gráfico de espectro
        espectro_graf_frame = tk.Frame(self.frame_espectro, bg="#2c3e50")
        espectro_graf_frame.pack(pady=10, fill=tk.BOTH, expand=True)
        
        # Crear figura y ejes para el espectro
        self.fig_espectro, self.ax_espectro = plt.subplots(figsize=(8, 4))
        self.fig_espectro.patch.set_facecolor('#2c3e50')
        self.ax_espectro.set_facecolor('#34495e')
        
        # Configurar ejes del espectro
        self.ax_espectro.set_title("ESPECTRO DE FRECUENCIAS - DETECCIÓN MUSICAL EN TIEMPO REAL", color='white', fontsize=12)
        self.ax_espectro.set_xlim(50, 1000)
        self.ax_espectro.set_ylim(0, 1.0)
        self.ax_espectro.set_xlabel("Frecuencia (Hz)", color='white')
        self.ax_espectro.set_ylabel("Magnitud Normalizada", color='white')
        self.ax_espectro.tick_params(colors='white')
        self.ax_espectro.grid(True, alpha=0.3, color='white')
        
        # Marcar frecuencias de las cuerdas de guitarra
        from config import CUERDAS_GUITARRA
        for cuerda, (freq, _, _) in CUERDAS_GUITARRA.items():
            self.ax_espectro.axvline(freq, color='#555555', linestyle='--', alpha=0.7)
            self.ax_espectro.text(freq, 0.95, cuerda, color='#aaaaaa', 
                                fontsize=8, ha='center', rotation=90)
        
        # Inicializar línea vacía
        x_empty = np.linspace(50, 1000, 100)
        y_empty = np.zeros(100)
        self.linea_espectro, = self.ax_espectro.plot(x_empty, y_empty, color='#00ff88', lw=1.5, alpha=0.8)
        
        # Marcadores para picos detectados
        self.marcadores_notas, = self.ax_espectro.plot([], [], 'ro', markersize=8, alpha=0.7, label='Notas Detectadas')
        
        self.ax_espectro.legend(facecolor='#2c3e50', edgecolor='white', labelcolor='white')
        
        self.canvas_espectro = FigureCanvasTkAgg(self.fig_espectro, master=espectro_graf_frame)
        self.canvas_espectro.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def actualizar_info_musical(self, acorde: str, info_acorde: str, notas_detectadas: List[Dict[str, Any]]):
        """Actualiza la información musical en el modo espectro"""
        try:
            self.lbl_acorde_espectro.config(text=f"Acorde: {acorde}", fg="#ff9900")
            self.lbl_info_acorde_espectro.config(text=f"Información: {info_acorde}", fg="#00ff00")
            
            if notas_detectadas:
                notas_nombres = [n['nota'] for n in notas_detectadas if n['nota'] is not None]
                if notas_nombres:
                    notas_texto = ", ".join(notas_nombres)
                    self.lbl_notas_espectro.config(text=f"Notas detectadas: {notas_texto}", fg="#00ff88")
                else:
                    self.lbl_notas_espectro.config(text="Notas detectadas: --", fg="#00ff88")
            else:
                self.lbl_notas_espectro.config(text="Notas detectadas: --", fg="#00ff88")
                
        except Exception as error:
            print(f"Error actualizando info musical: {error}")

    def actualizar_info_ruido(self):
        """Actualiza la información cuando se detecta ruido"""
        try:
            self.lbl_acorde_espectro.config(text="Acorde: RUIDO DETECTADO", fg="#ff6666")
            self.lbl_info_acorde_espectro.config(text="Información: Señal no musical", fg="#ff6666")
            self.lbl_notas_espectro.config(text="Notas detectadas: --", fg="#cccccc")
        except Exception as error:
            print(f"Error actualizando info ruido: {error}")

    def actualizar_info_silencio(self):
        """Actualiza la información cuando hay silencio"""
        try:
            self.lbl_acorde_espectro.config(text="Acorde: --", fg="#cccccc")
            self.lbl_info_acorde_espectro.config(text="Información: Silencio", fg="#cccccc")
            self.lbl_notas_espectro.config(text="Notas detectadas: --", fg="#cccccc")
            self.lbl_frecuencia_principal.config(text="Frecuencia Principal: -- Hz")
            self.lbl_volumen.config(text="Volumen: --")
        except Exception as error:
            print(f"Error actualizando info silencio: {error}")