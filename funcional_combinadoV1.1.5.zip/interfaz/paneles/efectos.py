import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from interfaz.ventana_principal import AfinadorGuitarraAcustica

class PanelEfectos:
    def __init__(self, parent, app: 'AfinadorGuitarraAcustica'):
        self.parent = parent
        self.app = app
        self.efecto_actual = "Filtro Pasa-Bajos"
        self.intensidad_actual = 50
        self.crear_interfaz()
    
    def crear_interfaz(self):
        self.frame_efectos = tk.Frame(self.parent, bg="#2c3e50", relief=tk.RAISED, bd=2)
        
        tk.Label(self.frame_efectos, 
                text="🎛️ PEDALERA DE EFECTOS DSP - Control ESP32", 
                font=("Arial", 14, "bold"),
                bg="#2c3e50", fg="white").pack(pady=15)
        
        # Controles de grabación
        grabacion_frame = tk.Frame(self.frame_efectos, bg="#2c3e50")
        grabacion_frame.pack(pady=10, fill=tk.X)
        
        self.btn_grabar = tk.Button(grabacion_frame, 
                                   text="⏺️ GRABAR 3 SEGUNDOS", 
                                   command=self.grabar_audio,
                                   bg="#e74c3c", fg="white", 
                                   font=("Arial", 11, "bold"),
                                   width=20)
        self.btn_grabar.pack(side=tk.LEFT, padx=10)
        
        self.lbl_estado_grabacion = tk.Label(grabacion_frame, 
                                           text="No grabado", 
                                           font=("Arial", 10),
                                           bg="#2c3e50", fg="#ecf0f1")
        self.lbl_estado_grabacion.pack(side=tk.LEFT, padx=10)
        
        # Selector de efectos
        efectos_frame = tk.Frame(self.frame_efectos, bg="#2c3e50")
        efectos_frame.pack(pady=10, fill=tk.X)
        
        tk.Label(efectos_frame, text="Efecto:", bg="#2c3e50", fg="white", 
                font=("Arial", 10)).pack(side=tk.LEFT, padx=10)
        
        self.efecto_var = tk.StringVar()
        opciones = ["Filtro Pasa-Bajos", "Distorsión", "Modulación", "Delay", "Reverb"]
        self.combo_efectos = ttk.Combobox(efectos_frame, textvariable=self.efecto_var, 
                                         values=opciones, state="readonly", width=20)
        self.combo_efectos.current(0)
        self.combo_efectos.pack(side=tk.LEFT, padx=10)
        
        tk.Label(efectos_frame, text="Intensidad:", bg="#2c3e50", fg="white",
                font=("Arial", 10)).pack(side=tk.LEFT, padx=10)
        
        self.slider_intensidad = tk.Scale(efectos_frame, from_=0, to=100, 
                                         orient=tk.HORIZONTAL, length=150, 
                                         bg="#34495e", fg="white", 
                                         highlightbackground="#2c3e50")
        self.slider_intensidad.set(50)
        self.slider_intensidad.pack(side=tk.LEFT, padx=10)
        
        self.btn_aplicar_efecto = tk.Button(efectos_frame, 
                                          text="⚡ APLICAR EFECTO", 
                                          command=self.aplicar_efecto,
                                          bg="#9b59b6", fg="white",
                                          font=("Arial", 10, "bold"))
        self.btn_aplicar_efecto.pack(side=tk.LEFT, padx=10)
        
        # Controles de reproducción
        reproduccion_frame = tk.Frame(self.frame_efectos, bg="#2c3e50")
        reproduccion_frame.pack(pady=15, fill=tk.X)
        
        self.btn_repro_original = tk.Button(reproduccion_frame, 
                                          text="▶ REPRODUCIR ORIGINAL", 
                                          command=self.reproducir_original,
                                          bg="#27ae60", fg="white",
                                          font=("Arial", 10),
                                          width=18)
        self.btn_repro_original.pack(side=tk.LEFT, padx=10)
        
        self.btn_repro_efecto = tk.Button(reproduccion_frame, 
                                        text="▶ REPRODUCIR CON EFECTO", 
                                        command=self.reproducir_con_efecto,
                                        bg="#e67e22", fg="white",
                                        font=("Arial", 10),
                                        width=20)
        self.btn_repro_efecto.pack(side=tk.LEFT, padx=10)
        
        self.btn_guardar = tk.Button(reproduccion_frame, 
                                   text="💾 GUARDAR RESULTADO", 
                                   command=self.guardar_resultado,
                                   bg="#3498db", fg="white",
                                   font=("Arial", 10))
        self.btn_guardar.pack(side=tk.LEFT, padx=10)
        
        self.btn_detener = tk.Button(reproduccion_frame, 
                                   text="⏹ DETENER", 
                                   command=self.detener_audio,
                                   bg="#e74c3c", fg="white",
                                   font=("Arial", 10))
        self.btn_detener.pack(side=tk.LEFT, padx=10)
        
        # Gráficas para efectos
        graficas_frame = tk.Frame(self.frame_efectos, bg="#2c3e50")
        graficas_frame.pack(pady=10, fill=tk.BOTH, expand=True)
        
        self.fig, (self.ax_original, self.ax_efecto) = plt.subplots(2, 1, figsize=(8, 4))
        self.fig.patch.set_facecolor('#2c3e50')
        
        # Configurar ejes
        for ax in [self.ax_original, self.ax_efecto]:
            ax.set_facecolor('#34495e')
            ax.tick_params(colors='white')
            ax.title.set_color('white')
            ax.xaxis.label.set_color('white')
            ax.yaxis.label.set_color('white')
            ax.spines['bottom'].set_color('white')
            ax.spines['top'].set_color('white')
            ax.spines['left'].set_color('white')
            ax.spines['right'].set_color('white')
            ax.grid(True, alpha=0.3, color='white')
        
        self.ax_original.set_title("Audio Original", color='white')
        self.ax_original.set_ylim(-1.1, 1.1)
        
        self.ax_efecto.set_title("Audio con Efecto", color='white')
        self.ax_efecto.set_ylim(-1.1, 1.1)
        
        self.canvas_efectos = FigureCanvasTkAgg(self.fig, master=graficas_frame)
        self.canvas_efectos.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Configurar eventos para cambios en tiempo real
        self.combo_efectos.bind('<<ComboboxSelected>>', self.actualizar_efecto_serial)
        self.slider_intensidad.configure(command=self.actualizar_intensidad_serial)
    
    def sincronizar_efecto_desde_serial(self, efecto):
        """Sincroniza el efecto recibido del ESP32 con la interfaz"""
        try:
            print(f"🔄 Sincronizando efecto desde serial: {efecto}")
            
            # Actualizar variable local
            self.efecto_actual = efecto
            
            # Actualizar combobox en la interfaz
            if efecto in self.combo_efectos['values']:
                self.efecto_var.set(efecto)
                print(f"✅ Combobox actualizado a: {efecto}")
                
                # Actualizar también en la app principal
                if hasattr(self.app, 'efecto_actual'):
                    self.app.efecto_actual = efecto
                    print(f"✅ Variable de app actualizada: {efecto}")
            else:
                print(f"⚠️ Efecto {efecto} no encontrado en combobox. Valores disponibles: {self.combo_efectos['values']}")
                
        except Exception as e:
            print(f"❌ Error sincronizando efecto: {e}")
    
    def actualizar_efecto_serial(self, event=None):
        """Actualiza el efecto actual y notifica al ESP32"""
        self.efecto_actual = self.efecto_var.get()
        
        # Actualizar en la app principal
        if hasattr(self.app, 'efecto_actual'):
            self.app.efecto_actual = self.efecto_actual
        
        # Notificar al ESP32
        if hasattr(self.app, 'serial_com') and self.app.serial_com and self.app.serial_com.conectado:
            self.app.serial_com.enviar_mensaje('E', self.efecto_actual, "Seleccionado", 
                                             f"Intensidad: {self.intensidad_actual}%", "")
            print(f"📤 Efecto enviado al ESP32: {self.efecto_actual}")
    
    def actualizar_intensidad_serial(self, valor):
        """Actualiza la intensidad actual y notifica al ESP32"""
        self.intensidad_actual = int(float(valor))
        
        # Actualizar en la app principal
        if hasattr(self.app, 'intensidad_actual'):
            self.app.intensidad_actual = self.intensidad_actual
            
        if hasattr(self.app, 'serial_com') and self.app.serial_com and self.app.serial_com.conectado:
            self.app.serial_com.enviar_mensaje('E', self.efecto_actual, "Intensidad", 
                                             f"{self.intensidad_actual}%", "")
    
    def grabar_audio(self):
        """Graba audio para aplicar efectos"""
        try:
            self.lbl_estado_grabacion.config(text="Grabando...")
            self.parent.update()
            
            audio = self.app.procesador_efectos.grabar_audio(duracion=3.0)
            self.lbl_estado_grabacion.config(text="Grabación completada")
            
            self.actualizar_grafica_audio(self.ax_original, audio, "Audio Original")
            
        except Exception as error:
            messagebox.showerror("Error", f"Error al grabar audio: {error}")
            self.lbl_estado_grabacion.config(text="Error en grabación")

    def aplicar_efecto(self):
        """Aplica el efecto seleccionado al audio grabado"""
        try:
            efecto = self.efecto_var.get()
            intensidad = self.slider_intensidad.get()
            
            # ACTUALIZAR VARIABLES PARA COMUNICACIÓN SERIAL
            self.efecto_actual = efecto
            self.intensidad_actual = intensidad
            
            if self.app.procesador_efectos.audio_original is None:
                messagebox.showwarning("Advertencia", "Primero graba audio antes de aplicar efectos")
                return
            
            audio_procesado = self.app.procesador_efectos.aplicar_efecto(efecto, intensidad)
            self.lbl_estado_grabacion.config(text=f"Efecto aplicado: {efecto}")
            
            # ENVIAR A ESP32
            if hasattr(self.app, 'serial_com') and self.app.serial_com and self.app.serial_com.conectado:
                self.app.serial_com.enviar_mensaje('E', efecto, "Aplicado", 
                                                 f"Intensidad: {intensidad}%", "Listo para reproducir")
            
            self.actualizar_grafica_audio(self.ax_efecto, audio_procesado, f"Audio con {efecto}")
            
        except Exception as error:
            messagebox.showerror("Error", f"Error al aplicar efecto: {error}")

    def reproducir_original(self):
        """Reproduce el audio original"""
        try:
            self.app.procesador_efectos.reproducir_original()
        except Exception as error:
            messagebox.showerror("Error", f"Error al reproducir audio original: {error}")

    def reproducir_con_efecto(self):
        """Reproduce el audio con efecto aplicado"""
        try:
            self.app.procesador_efectos.reproducir_procesado()
        except Exception as error:
            messagebox.showerror("Error", f"Error al reproducir audio con efecto: {error}")

    def detener_audio(self):
        """Detiene la reproducción de audio"""
        import sounddevice as sd
        sd.stop()

    def guardar_resultado(self):
        """Guarda el audio procesado en un archivo"""
        try:
            if self.app.procesador_efectos.audio_procesado is None:
                messagebox.showwarning("Advertencia", "Primero aplica un efecto antes de guardar")
                return
            
            archivo = filedialog.asksaveasfilename(
                defaultextension=".wav",
                filetypes=[("Archivos WAV", "*.wav"), ("Todos los archivos", "*.*")]
            )
            
            if archivo:
                self.app.procesador_efectos.guardar_audio(archivo, self.app.procesador_efectos.audio_procesado)
                messagebox.showinfo("Éxito", f"Audio guardado en: {archivo}")
                
        except Exception as error:
            messagebox.showerror("Error", f"Error al guardar archivo: {error}")

    def actualizar_despues_grabacion(self, audio_data):
        """Actualiza la interfaz después de una grabación"""
        try:
            print("🔄 Actualizando interfaz después de grabación...")
            self.lbl_estado_grabacion.config(text="Grabación completada")
            self.actualizar_grafica_audio(self.ax_original, audio_data, "Audio Original")
            print("✅ Interfaz actualizada después de grabación")
        except Exception as e:
            print(f"❌ Error actualizando después de grabación: {e}")

    def actualizar_despues_efecto(self, audio_procesado, efecto):
        """Actualiza la interfaz después de aplicar un efecto"""
        try:
            print(f"🔄 Actualizando interfaz después de efecto: {efecto}")
            self.lbl_estado_grabacion.config(text=f"Efecto aplicado: {efecto}")
            self.actualizar_grafica_audio(self.ax_efecto, audio_procesado, f"Audio con {efecto}")
            print(f"✅ Interfaz actualizada después de efecto: {efecto}")
        except Exception as e:
            print(f"❌ Error actualizando después de efecto: {e}")


    def actualizar_grafica_audio(self, ax, audio_data: np.ndarray, titulo: str):
        """Actualiza las gráficas de audio"""
        try:
            ax.clear()
            ax.set_title(titulo, color='white')
            ax.set_ylim(-1.1, 1.1)
            ax.grid(True, alpha=0.3, color='white')
            
            if audio_data is not None and len(audio_data) > 0:
                muestras = min(len(audio_data), 10000)
                indices = np.linspace(0, len(audio_data)-1, muestras, dtype=int)
                ax.plot(indices, audio_data[indices], color='#3498db', lw=1)
            
            self.canvas_efectos.draw()
            
        except Exception as error:
            print(f"Error actualizando gráfica: {error}")