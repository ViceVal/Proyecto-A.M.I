import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from interfaz.ventana_principal import AfinadorGuitarraAcustica

class PanelAfinador:
    def __init__(self, parent, app: 'AfinadorGuitarraAcustica'):
        self.parent = parent
        self.app = app
        self.crear_interfaz()
    
    def crear_interfaz(self):
        self.frame_afinador = tk.Frame(self.parent, bg="#ecf0f1", relief=tk.RAISED, bd=2)
        
        self.lbl_resultado = tk.Label(self.frame_afinador, 
                                     text="--", 
                                     font=("Arial", 32, "bold"), 
                                     bg="#ecf0f1", fg="#7f8c8d")
        self.lbl_resultado.pack(pady=10)
        
        info_frame_af = tk.Frame(self.frame_afinador, bg="#ecf0f1")
        info_frame_af.pack(pady=8)
        
        self.lbl_frecuencia = tk.Label(info_frame_af, 
                                      text="0.00 Hz", 
                                      font=("Arial", 11),
                                      bg="#ecf0f1")
        self.lbl_frecuencia.pack(side=tk.LEFT, padx=10)
        
        self.lbl_cuerda = tk.Label(info_frame_af, 
                                  text="--", 
                                  font=("Arial", 11, "bold"),
                                  bg="#ecf0f1")
        self.lbl_cuerda.pack(side=tk.LEFT, padx=10)
        
        self.lbl_desviacion = tk.Label(info_frame_af, 
                                      text="±0 cents", 
                                      font=("Arial", 10),
                                      bg="#ecf0f1")
        self.lbl_desviacion.pack(side=tk.LEFT, padx=10)
        
        self.crear_indicador_afinacion()
    
    def crear_indicador_afinacion(self):
        frame = tk.Frame(self.frame_afinador, bg="#ecf0f1")
        frame.pack(pady=10)
        
        self.canvas_afinacion = tk.Canvas(frame, width=300, height=60, bg="#2c3e50")
        self.canvas_afinacion.pack()
        
        for cents in [-50, -25, 0, 25, 50]:
            x = 150 + cents
            color = "#e74c3c" if cents == 0 else "#7f8c8d"
            self.canvas_afinacion.create_line(x, 20, x, 40, fill=color, width=2)
            self.canvas_afinacion.create_text(x, 50, text=str(cents), fill="white", font=("Arial", 8))
        
        self.aguja = self.canvas_afinacion.create_line(150, 15, 150, 45, fill="#3498db", width=3)
    
    def mostrar_afinacion(self, frecuencia: float, cuerda: str):
        try:
            self.lbl_resultado.config(text=cuerda, fg="#2c3e50")
            self.lbl_frecuencia.config(text=f"{frecuencia:.1f} Hz")
            self.lbl_cuerda.config(text=cuerda)
            
            from utils import calcular_desviacion_cents, obtener_frecuencia_objetivo
            freq_objetivo = obtener_frecuencia_objetivo(cuerda)
            cents = calcular_desviacion_cents(frecuencia, freq_objetivo)
            
            desplazamiento = cents * 0.5
            nueva_x = max(50, min(250, 150 + desplazamiento))
            self.canvas_afinacion.coords(self.aguja, nueva_x, 15, nueva_x, 45)
            
            if abs(cents) < 3:
                color = "#2ecc71"
                accion = "PERFECTO"
            elif abs(cents) < 10:
                color = "#f39c12"
                direccion = "APRETAR" if cents > 0 else "AFLOJAR"
                accion = f"{direccion}"
            else:
                color = "#e74c3c"
                direccion = "APRETAR" if cents > 0 else "AFLOJAR"
                accion = f"{direccion} FUERTE"
                
            self.canvas_afinacion.itemconfig(self.aguja, fill=color)
            self.lbl_desviacion.config(text=f"{accion} ({cents:+.1f} cents)")
            
        except Exception as error:
            print(f"Error en mostrar_afinacion: {error}")
            self.mostrar_silencio()
    
    def mostrar_silencio(self):
        self.lbl_resultado.config(text="--", fg="#7f8c8d")
        self.lbl_frecuencia.config(text="0.00 Hz")
        self.lbl_cuerda.config(text="--")
        self.lbl_desviacion.config(text="±0 cents")
        self.canvas_afinacion.coords(self.aguja, 150, 15, 150, 45)
        self.canvas_afinacion.itemconfig(self.aguja, fill="#3498db")