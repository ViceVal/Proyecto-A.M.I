import tkinter as tk
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from interfaz.ventana_principal import AfinadorGuitarraAcustica

class PanelAcordes:
    def __init__(self, parent, app: 'AfinadorGuitarraAcustica'):
        self.parent = parent
        self.app = app
        self.crear_interfaz()
    
    def crear_interfaz(self):
        self.frame_acordes = tk.Frame(self.parent, bg="#ecf0f1", relief=tk.RAISED, bd=2)
        
        tk.Label(self.frame_acordes, 
                text="DETECCIÓN DE ACORDES CON ANÁLISIS FOURIER", 
                font=("Arial", 12, "bold"),
                bg="#ecf0f1").pack(pady=10)
        
        self.lbl_acorde_principal = tk.Label(self.frame_acordes, 
                                           text="--", 
                                           font=("Arial", 28, "bold"),
                                           bg="#ecf0f1", fg="#2c3e50")
        self.lbl_acorde_principal.pack(pady=5)
        
        self.lbl_info_acorde = tk.Label(self.frame_acordes, 
                                      text="Toca un acorde...", 
                                      font=("Arial", 10),
                                      bg="#ecf0f1", fg="#7f8c8d")
        self.lbl_info_acorde.pack(pady=2)
        
        self.lbl_notas_detectadas = tk.Label(self.frame_acordes, 
                                           text="Notas: --", 
                                           font=("Arial", 9),
                                           bg="#ecf0f1", fg="#34495e")
        self.lbl_notas_detectadas.pack(pady=2)
        
        self.lbl_frecuencias_detectadas = tk.Label(self.frame_acordes, 
                                                 text="Frecuencias: --", 
                                                 font=("Arial", 8),
                                                 bg="#ecf0f1", fg="#95a5a6")
        self.lbl_frecuencias_detectadas.pack(pady=2)
    
    def mostrar_acorde(self, acorde: str, info: str, notas: List[str], frecuencias: List[float]):
        try:
            self.lbl_acorde_principal.config(text=acorde)
            self.lbl_info_acorde.config(text=info)
            
            if notas:
                self.lbl_notas_detectadas.config(text=f"Notas: {', '.join(notas)}")
                frec_str = ", ".join([f"{f:.1f}Hz" for f in frecuencias])
                self.lbl_frecuencias_detectadas.config(text=f"Frecuencias: {frec_str}")
            else:
                self.lbl_notas_detectadas.config(text="Notas: --")
                self.lbl_frecuencias_detectadas.config(text="Frecuencias: --")
            
        except Exception as error:
            print(f"Error en mostrar_acorde: {error}")
            self.mostrar_silencio()
    
    def mostrar_silencio(self):
        tiempo_actual = time.time()
        ultimo_tiempo = self.app.procesador.detector_notas.tiempo_ultimo_acorde
        
        if (not self.app.procesador.detector_notas.ultimo_acorde_detectado or 
            tiempo_actual - ultimo_tiempo >= 2.0):
            self.lbl_acorde_principal.config(text="--")
            self.lbl_info_acorde.config(text="Toca un acorde...")
            self.lbl_notas_detectadas.config(text="Notas: --")
            self.lbl_frecuencias_detectadas.config(text="Frecuencias: --")