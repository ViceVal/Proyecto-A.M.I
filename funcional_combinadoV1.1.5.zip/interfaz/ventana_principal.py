import tkinter as tk
from tkinter import ttk
import sounddevice as sd
import numpy as np
from scipy.signal import find_peaks
import time
from typing import Optional, Any, List, Dict

from config import FRECUENCIA_MUESTREO, TAMANO_BLOQUE, UMBRAL_VOLUMEN
from procesadores.procesador_guitarra import ProcesadorGuitarraAcustica
from procesadores.efectos import ProcesadorEfectos
from interfaz.paneles.afinador import PanelAfinador
from interfaz.paneles.acordes import PanelAcordes
from interfaz.paneles.espectro import PanelEspectro
from interfaz.paneles.efectos import PanelEfectos
from utils import calcular_desviacion_cents, obtener_frecuencia_objetivo

class AfinadorGuitarraAcustica:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("🎸 Asistente Musical Inteligente")
        self.root.geometry("900x800")
        
        self.escuchando: bool = False
        self.modo_actual: str = "afinador"
        self.stream: Optional[sd.InputStream] = None
        self.procesando_audio: bool = False
        
        self.procesador = ProcesadorGuitarraAcustica()
        self.procesador_efectos = ProcesadorEfectos()
        self.procesador_efectos.set_callback_actualizacion(self.actualizar_interfaz_efectos)

        # Inicializar paneles
        self.panel_afinador: Optional[PanelAfinador] = None
        self.panel_acordes: Optional[PanelAcordes] = None
        self.panel_espectro: Optional[PanelEspectro] = None
        self.panel_efectos: Optional[PanelEfectos] = None
        
        # Variables para comunicación serial - INICIALIZAR COMO NONE
        self.serial_com = None
        self.ejecutando = True
        self.efecto_actual = "Filtro Pasa-Bajos"
        self.intensidad_actual = 50
        
        self.crear_interfaz()
        self.inicializar_audio()

    def crear_interfaz(self) -> None:
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Título principal
        title_label = tk.Label(main_frame, 
                              text="🎸 Asistente Musical Inteligente", 
                              font=("Arial", 14, "bold"))
        title_label.pack(pady=10)
        
        # Menú de navegación
        menu_frame = tk.Frame(main_frame, bg="#34495e")
        menu_frame.pack(fill=tk.X, pady=5, padx=10)
        
        self.btn_afinador = tk.Button(menu_frame, 
                                     text="🎵 AFINADOR", 
                                     command=self.activar_modo_afinador,
                                     bg="#3498db", fg="white", 
                                     font=("Arial", 10, "bold"),
                                     width=12, height=2)
        self.btn_afinador.pack(side=tk.LEFT, padx=2)
        
        self.btn_acordes = tk.Button(menu_frame, 
                                    text="🎶 DETECTOR ACORDES", 
                                    command=self.activar_modo_acordes,
                                    bg="#95a5a6", fg="white", 
                                    font=("Arial", 10, "bold"),
                                    width=12, height=2)
        self.btn_acordes.pack(side=tk.LEFT, padx=2)
        
        self.btn_espectro = tk.Button(menu_frame, 
                                     text="📈 VISUALIZAR ESPECTRO", 
                                     command=self.activar_modo_espectro,
                                     bg="#95a5a6", fg="white", 
                                     font=("Arial", 10, "bold"),
                                     width=12, height=2)
        self.btn_espectro.pack(side=tk.LEFT, padx=2)
        
        self.btn_efectos = tk.Button(menu_frame, 
                                    text="🎛️ PEDALERA", 
                                    command=self.activar_modo_efectos,
                                    bg="#95a5a6", fg="white", 
                                     font=("Arial", 10, "bold"),
                                     width=12, height=2)
        self.btn_efectos.pack(side=tk.LEFT, padx=2)
        
        # Crear paneles
        self.panel_afinador = PanelAfinador(main_frame, self)
        self.panel_acordes = PanelAcordes(main_frame, self)
        self.panel_espectro = PanelEspectro(main_frame, self)
        self.panel_efectos = PanelEfectos(main_frame, self)
        
        # Estado y controles generales
        self.lbl_estado = tk.Label(main_frame, 
                                  text="Selecciona un modo y presiona INICIAR", 
                                  font=("Arial", 10))
        self.lbl_estado.pack(pady=8)
        
        controles_frame = tk.Frame(main_frame)
        controles_frame.pack(pady=10)
        
        self.btn_captura = tk.Button(controles_frame, 
                                    text="🎙️ INICIAR CAPTURA", 
                                    command=self.toggle_captura,
                                    bg="#27ae60", fg="white", 
                                    font=("Arial", 11, "bold"),
                                    width=15, height=1)
        self.btn_captura.pack(side=tk.LEFT, padx=5)
        
        self.btn_detener_main = tk.Button(controles_frame, 
                                        text="🛑 DETENER", 
                                        command=self.detener_captura,
                                        bg="#e74c3c", fg="white", 
                                        font=("Arial", 11, "bold"),
                                        width=12, height=1)
        self.btn_detener_main.pack(side=tk.LEFT, padx=5)
        
        # Mostrar modo afinador por defecto
        self.activar_modo_afinador()

    def inicializar_audio(self) -> None:
        try:
            self.stream = sd.InputStream(
                callback=self.audio_callback,
                channels=1,
                samplerate=FRECUENCIA_MUESTREO,
                blocksize=TAMANO_BLOQUE,
                latency='low'
            )
            print("✅ Sistema de audio inicializado")
        except Exception as error:
            print(f"Error audio: {error}")

    def es_ruido_o_musica(self, audio_data: np.ndarray, f: np.ndarray, magnitudes: np.ndarray) -> str:
        """Determina si la señal es ruido o música basado en características espectrales"""
        try:
            volumen = np.sqrt(np.mean(audio_data**2))
            
            if volumen < UMBRAL_VOLUMEN * 2:
                return "silencio"
            
            mascara_musica = (f >= 80) & (f <= 450)
            if not np.any(mascara_musica):
                return "ruido"
            
            energia_musica = np.sum(magnitudes[mascara_musica])
            energia_total = np.sum(magnitudes)
            
            if energia_total == 0:
                return "ruido"
            
            relacion_musica = energia_musica / energia_total
            
            picos, _ = find_peaks(magnitudes[mascara_musica], 
                                height=0.1*np.max(magnitudes[mascara_musica]),
                                distance=5,
                                prominence=0.05*np.max(magnitudes[mascara_musica]))
            
            num_picos_prominentes = len(picos)
            
            if relacion_musica > 0.3 and num_picos_prominentes >= 1:
                return "musica"
            elif relacion_musica > 0.6 and num_picos_prominentes >= 2:
                return "musica"
            elif volumen > UMBRAL_VOLUMEN * 10 and num_picos_prominentes == 0:
                return "ruido"
            else:
                return "ruido"
                
        except Exception:
            return "ruido"

    def audio_callback(self, indata: np.ndarray, frames: int, callback_time: Any, status: Any) -> None:
        if not self.escuchando or self.procesando_audio:
            return
        
        if indata is None or len(indata) == 0:
            self.procesando_audio = False
            self.safe_after(self.mostrar_silencio)
            return
        
        self.procesando_audio = True
        
        try:
            audio_data = indata[:, 0]
            if audio_data is None or len(audio_data) == 0:
                self.safe_after(self.mostrar_silencio)
                return
            
            audio_flat = audio_data.flatten().astype(np.float64)

            volumen = np.sqrt(np.mean(audio_flat**2)) if len(audio_flat) > 0 else 0
            
            # VISUALIZADOR DE ESPECTRO CON DETECCIÓN MUSICAL MEJORADA
            if self.modo_actual == "espectro" and len(audio_flat) > 0:
                try:
                    f, magnitudes = self.procesador.detector_notas.calcular_espectro_mejorado(audio_flat)
                    if len(f) > 0 and len(magnitudes) > 0 and self.panel_espectro.linea_espectro is not None:
                        
                        tipo_senal = self.es_ruido_o_musica(audio_flat, f, magnitudes)
                        
                        self.safe_after(lambda: self.panel_espectro.lbl_estado_deteccion.config(
                            text=f"Estado: {tipo_senal.upper()}",
                            fg="#ffff00" if tipo_senal == "ruido" else "#00ff00" if tipo_senal == "musica" else "#cccccc"
                        ))
                        
                        if tipo_senal == "musica":
                            notas_detectadas = self.procesador.detector_notas.detectar_notas_en_audio(audio_flat)
                            acorde, info_acorde = self.procesador.detectar_acorde_completo(audio_flat)
                            
                            self.safe_after(lambda: self.panel_espectro.actualizar_info_musical(acorde, info_acorde, notas_detectadas))
                            
                            mascara = (f >= 50) & (f <= 1000)
                            if np.any(mascara):
                                idx_principal = np.argmax(magnitudes[mascara])
                                freq_principal = f[mascara][idx_principal]
                                
                                self.safe_after(lambda: self.panel_espectro.lbl_frecuencia_principal.config(
                                    text=f"Frecuencia Principal: {freq_principal:.1f} Hz"
                                ))
                                
                        elif tipo_senal == "ruido":
                            mascara = (f >= 50) & (f <= 1000)
                            if np.any(mascara):
                                idx_principal = np.argmax(magnitudes[mascara])
                                freq_principal = f[mascara][idx_principal]
                                
                                self.safe_after(lambda: self.panel_espectro.lbl_frecuencia_principal.config(
                                    text=f"Ruido - Frecuencia dominante: {freq_principal:.1f} Hz"
                                ))
                            
                            self.safe_after(self.panel_espectro.actualizar_info_ruido)
                            
                        else:
                            self.safe_after(self.panel_espectro.actualizar_info_silencio)
                        
                        if np.max(magnitudes) > 0:
                            magnitudes_norm = magnitudes / np.max(magnitudes)
                        else:
                            magnitudes_norm = magnitudes
                        
                        self.panel_espectro.linea_espectro.set_data(f, magnitudes_norm)
                        
                        if tipo_senal == "musica" and notas_detectadas:
                            frecuencias_notas = [n['frecuencia'] for n in notas_detectadas if n['nota'] is not None]
                            magnitudes_notas = [n['magnitud'] for n in notas_detectadas if n['nota'] is not None]
                            
                            if frecuencias_notas and magnitudes_notas:
                                max_mag = max(magnitudes_notas) if magnitudes_notas else 1.0
                                magnitudes_notas_norm = [mag/max_mag * 0.8 for mag in magnitudes_notas]
                                self.panel_espectro.marcadores_notas.set_data(frecuencias_notas, magnitudes_notas_norm)
                        else:
                            self.panel_espectro.marcadores_notas.set_data([], [])
                        
                        self.safe_after(lambda: self.panel_espectro.lbl_volumen.config(
                            text=f"Volumen: {volumen:.4f}"
                        ))
                        
                        if self.panel_espectro.canvas_espectro is not None:
                            self.panel_espectro.canvas_espectro.draw_idle()
                            
                except Exception as spec_error:
                    print(f"Error en visualizador espectro: {spec_error}")
            
            if volumen < UMBRAL_VOLUMEN:
                self.safe_after(self.mostrar_silencio)
            else:
                # Procesar según el modo actual
                if self.modo_actual == "afinador" and len(audio_flat) > 0:
                    frecuencia, cuerda = self.procesador.detectar_fundamental_segura(audio_flat)
                    if frecuencia and cuerda:
                        freq_estable, cuerda_estable = self.procesador.procesar_estabilidad_segura(frecuencia, cuerda)
                        if freq_estable and cuerda_estable:
                            self.safe_after(lambda: self.mostrar_afinacion(freq_estable, cuerda_estable))
                    else:
                        self.safe_after(self.mostrar_silencio)
                    
                elif self.modo_actual == "acordes" and len(audio_flat) > 0:
                    acorde, info = self.procesador.detectar_acorde_completo(audio_flat)
                    notas_detectadas = self.procesador.detector_notas.detectar_notas_en_audio(audio_flat)
                    notas_nombres = [n['nota'] for n in notas_detectadas if n['nota'] is not None]
                    frecuencias = [n['frecuencia'] for n in notas_detectadas]
                
                    self.safe_after(lambda: self.mostrar_acorde(acorde, info, notas_nombres, frecuencias))
                    
        except Exception as error:
            print(f"Error en callback: {error}")
            self.safe_after(self.mostrar_silencio)
        finally:
            self.procesando_audio = False

    def safe_after(self, func) -> None:
        """Método seguro para llamar after() desde el callback"""
        try:
            if self.root and hasattr(self.root, 'winfo_exists') and self.root.winfo_exists():
                self.root.after(0, func)
        except Exception as error:
            print(f"Error en safe_after: {error}")

    def toggle_captura(self) -> None:
        if not self.escuchando:
            self.escuchando = True
            try:
                if self.stream:
                    self.stream.start()
                self.btn_captura.config(text="🎙️ CAPTURANDO...", bg="#e74c3c")
                estado = "Escuchando... " + {
                    "afinador": "Toca una cuerda",
                    "acordes": "Toca un acorde", 
                    "espectro": "Analizando espectro y música",
                    "efectos": "Modo pedalera"
                }[self.modo_actual]
                self.lbl_estado.config(text=estado)
                
                # Enviar estado a ESP32 solo si está conectado
                if self.serial_com and hasattr(self.serial_com, 'conectado') and self.serial_com.conectado:
                    self.serial_com.enviar_mensaje('A', "Capturando...", "Esperando señal", "audio", "")
                    
            except Exception as error:
                print(f"Error al iniciar stream: {error}")
                self.escuchando = False
                self.btn_captura.config(text="🎙️ INICIAR", bg="#27ae60")
                self.lbl_estado.config(text="Error al iniciar audio")
        else:
            self.detener_captura()

    def detener_captura(self) -> None:
        """Detiene la captura de audio de forma segura"""
        self.escuchando = False
        if self.stream:
            try:
                self.stream.stop()
            except Exception as error:
                print(f"Error al detener stream: {error}")
        self.btn_captura.config(text="🎙️ INICIAR", bg="#27ae60")
        self.lbl_estado.config(text="Captura detenida")
        
        # Enviar estado a ESP32 solo si está conectado
        if self.serial_com and hasattr(self.serial_com, 'conectado') and self.serial_com.conectado:
            self.serial_com.enviar_mensaje('A', "Captura detenida", "Presiona A para", "reanudar", "")
            
        self.mostrar_silencio()

    def mostrar_silencio(self) -> None:
        try:
            if self.modo_actual == "afinador":
                self.panel_afinador.mostrar_silencio()
            elif self.modo_actual == "acordes":
                self.panel_acordes.mostrar_silencio()
            elif self.modo_actual == "espectro":
                self.panel_espectro.actualizar_info_silencio()
                self.panel_espectro.lbl_estado_deteccion.config(text="Estado: Silencio", fg="#cccccc")
                if self.panel_espectro.linea_espectro is not None:
                    x_empty = np.linspace(50, 1000, 100)
                    y_empty = np.zeros(100)
                    self.panel_espectro.linea_espectro.set_data(x_empty, y_empty)
                    self.panel_espectro.marcadores_notas.set_data([], [])
                    if self.panel_espectro.canvas_espectro is not None:
                        self.panel_espectro.canvas_espectro.draw_idle()
            
            self.lbl_estado.config(text="Toca tu guitarra o habla al micrófono...")
            
            # Enviar estado de silencio a ESP32 solo si está conectado
            if (self.serial_com and hasattr(self.serial_com, 'conectado') and 
                self.serial_com.conectado and self.modo_actual == "afinador"):
                self.serial_com.enviar_mensaje('A', "--", "Silencio", "0 cents", "0 Hz")
                
        except Exception as error:
            print(f"Error en mostrar_silencio: {error}")

    def activar_modo_afinador(self) -> None:
        self.modo_actual = "afinador"
        self.actualizar_botones_menu()
        self.ocultar_todos_frames()
        self.panel_afinador.frame_afinador.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)
        self.lbl_estado.config(text="Modo Afinador - Toca una cuerda individual de guitarra")
        
        # Enviar a ESP32 solo si está conectado
        if self.serial_com and hasattr(self.serial_com, 'conectado') and self.serial_com.conectado:
            self.serial_com.enviar_mensaje('A', "Modo Afinador", "Listo", "Presiona A para", "capturar")

    def activar_modo_acordes(self) -> None:
        self.modo_actual = "acordes"
        self.actualizar_botones_menu()
        self.ocultar_todos_frames()
        self.panel_acordes.frame_acordes.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)
        self.lbl_estado.config(text="Modo Acordes - Toca un acorde completo de guitarra")

    def activar_modo_espectro(self) -> None:
        self.modo_actual = "espectro"
        self.actualizar_botones_menu()
        self.ocultar_todos_frames()
        self.panel_espectro.frame_espectro.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)
        self.lbl_estado.config(text="Modo Espectro - Visualizando espectro con detección musical en tiempo real")

    def activar_modo_efectos(self) -> None:
        self.modo_actual = "efectos"
        self.actualizar_botones_menu()
        self.ocultar_todos_frames()
        self.panel_efectos.frame_efectos.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)
        self.lbl_estado.config(text="Modo Efectos - Graba audio y aplica efectos DSP")
        
        # Enviar a ESP32 solo si está conectado
        if self.serial_com and hasattr(self.serial_com, 'conectado') and self.serial_com.conectado:
            self.serial_com.enviar_mensaje('E', "Modo Efectos", "Listo", "Presiona A para", "grabar audio")

    def actualizar_botones_menu(self) -> None:
        """Actualiza los colores de los botones del menú"""
        botones = {
            "afinador": self.btn_afinador,
            "acordes": self.btn_acordes,
            "espectro": self.btn_espectro,
            "efectos": self.btn_efectos
        }
        
        for modo, boton in botones.items():
            if modo == self.modo_actual:
                boton.config(bg="#3498db")
            else:
                boton.config(bg="#95a5a6")

    def ocultar_todos_frames(self) -> None:
        """Oculta todos los frames de contenido"""
        frames = [
            self.panel_afinador.frame_afinador,
            self.panel_acordes.frame_acordes,
            self.panel_espectro.frame_espectro,
            self.panel_efectos.frame_efectos
        ]
        for frame in frames:
            frame.pack_forget()

    # =========================
    # MÉTODOS DE COMUNICACIÓN SERIAL
    # =========================
    
    def enviar_estado_afinador(self, frecuencia, cuerda, desviacion, estado):
        """Envía información del afinador al ESP32"""
        if self.serial_com and hasattr(self.serial_com, 'conectado') and self.serial_com.conectado:
            cents = f"{desviacion:+.1f} cents" if desviacion != 0 else "0 cents"
            self.serial_com.enviar_mensaje('A', cuerda, estado, cents, f"{frecuencia:.1f} Hz")

    def enviar_estado_efectos(self, efecto, intensidad, estado):
        """Envía información de efectos al ESP32"""
        if self.serial_com and hasattr(self.serial_com, 'conectado') and self.serial_com.conectado:
            self.serial_com.enviar_mensaje('E', efecto, f"Intensidad: {intensidad}%", estado, "")

    def mostrar_afinacion(self, frecuencia: float, cuerda: str):
        try:
            self.panel_afinador.lbl_resultado.config(text=cuerda, fg="#2c3e50")
            self.panel_afinador.lbl_frecuencia.config(text=f"{frecuencia:.1f} Hz")
            self.panel_afinador.lbl_cuerda.config(text=cuerda)
            
            freq_objetivo = obtener_frecuencia_objetivo(cuerda)
            cents = calcular_desviacion_cents(frecuencia, freq_objetivo)
            
            desplazamiento = cents * 0.5
            nueva_x = max(50, min(250, 150 + desplazamiento))
            self.panel_afinador.canvas_afinacion.coords(self.panel_afinador.aguja, nueva_x, 15, nueva_x, 45)
            
            if abs(cents) < 3:
                color = "#2ecc71"
                accion = "PERFECTO"
            elif abs(cents) < 10:
                color = "#f39c12"
                direccion = "APRETAR" if cents > 0 else "AFLOJAR"
                accion = f"{direccion}"
            else:
                color = "#e74c3c"
                direccion = "APRETAR" if cents > 0 else "AFLOJAR"
                accion = f"{direccion} FUERTE"
                
            self.panel_afinador.canvas_afinacion.itemconfig(self.panel_afinador.aguja, fill=color)
            self.panel_afinador.lbl_desviacion.config(text=f"{accion} ({cents:+.1f} cents)")
            
            # ENVIAR DATOS AL ESP32 solo si está conectado
            if self.serial_com and hasattr(self.serial_com, 'conectado') and self.serial_com.conectado:
                self.enviar_estado_afinador(frecuencia, cuerda, cents, accion)
            
        except Exception as error:
            print(f"Error en mostrar_afinacion: {error}")
            self.mostrar_silencio()

    def mostrar_acorde(self, acorde: str, info: str, notas: List[str], frecuencias: List[float]):
        try:
            self.panel_acordes.lbl_acorde_principal.config(text=acorde)
            self.panel_acordes.lbl_info_acorde.config(text=info)
            
            if notas:
                self.panel_acordes.lbl_notas_detectadas.config(text=f"Notas: {', '.join(notas)}")
                frec_str = ", ".join([f"{f:.1f}Hz" for f in frecuencias])
                self.panel_acordes.lbl_frecuencias_detectadas.config(text=f"Frecuencias: {frec_str}")
            else:
                self.panel_acordes.lbl_notas_detectadas.config(text="Notas: --")
                self.panel_acordes.lbl_frecuencias_detectadas.config(text="Frecuencias: --")
            
            self.lbl_estado.config(text=f"Acorde: {acorde}")
            
        except Exception as error:
            print(f"Error en mostrar_acorde: {error}")
            self.mostrar_silencio()

    def actualizar_interfaz_efectos(self, evento, audio_data=None, efecto=None):
        """Callback para actualizar la interfaz desde el procesador de efectos"""
        try:
            if self.modo_actual == "efectos" and hasattr(self, 'panel_efectos'):
                if evento == 'grabacion_completada':
                    print("🎙️ Callback: Grabación completada, actualizando interfaz...")
                    self.panel_efectos.actualizar_despues_grabacion(audio_data)
                elif evento == 'efecto_aplicado':
                    print(f"🎛️ Callback: Efecto {efecto} aplicado, actualizando interfaz...")
                    self.panel_efectos.actualizar_despues_efecto(audio_data, efecto)
        except Exception as e:
            print(f"❌ Error en callback de actualización: {e}")
    
    def cerrar_aplicacion(self) -> None:
        """Cierra la aplicación de forma segura"""
        print("Cerrando aplicación...")
        self.detener_captura()
        sd.stop()
        if self.stream:
            try:
                self.stream.close()
                print("Stream de audio cerrado")
            except Exception as error:
                print(f"Error al cerrar stream: {error}")
        import matplotlib.pyplot as plt
        plt.close('all')
        self.root.quit()
        self.root.destroy()