import math
from config import CUERDAS_GUITARRA

def calcular_desviacion_cents(f_medida: float, f_objetivo: float) -> float:
    if f_medida <= 0 or f_objetivo <= 0:
        return 0.0
    try:
        return 1200 * math.log2(f_medida / f_objetivo)
    except Exception:
        return 0.0

def obtener_frecuencia_objetivo(cuerda: str) -> float:
    if cuerda in CUERDAS_GUITARRA:
        return CUERDAS_GUITARRA[cuerda][0]
    return 0.0