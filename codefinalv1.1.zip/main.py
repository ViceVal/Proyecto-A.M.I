# main.py - VERSIÓN CORREGIDA
import tkinter as tk
from gui_interfaz import AfinadorGuitarraAcusticaGUI
from core_esp32_serial import ESP32Bridge
import time

def main():
    print("INICIANDO SISTEMA DE AFINADOR + EFECTOS")
    print("=" * 50)

    # -----------------------------------------------------------
    # 1. Crear y configurar puente con ESP32
    # -----------------------------------------------------------
    esp32 = ESP32Bridge()
    
    # Listar puertos disponibles
    print("Buscando puertos seriales...")
    puertos = esp32.listar_puertos()
    if not puertos:
        print("ERROR: No se encontraron puertos COM disponibles")
        print("Conecta el ESP32 y verifica los drivers")
    else:
        print(f"Detectados {len(puertos)} puertos")
    
    # Intentar conexión automática
    conexion_exitosa = esp32.conectar()
    if conexion_exitosa:
        print("ESP32 conectado exitosamente")
    else:
        print("Ejecutando en modo sin ESP32 - Solo interfaz local")

    # -----------------------------------------------------------
    # 2. Crear la ventana principal
    # -----------------------------------------------------------
    root = tk.Tk()
    app = AfinadorGuitarraAcusticaGUI(root)

    # -----------------------------------------------------------
    # 3. Enlazar datos desde ESP32 -> GUI (si hay conexión)
    # -----------------------------------------------------------
    if esp32.esta_conectado():
        esp32.agregar_listener(app.on_esp32_data)
        esp32.iniciar_escucha()
        print("CONECTADO al ESP32 - Escuchando mensajes...")
    else:
        print("MODO SIN ESP32 - Funcionando solo con interfaz local")

    # -----------------------------------------------------------
    # 4. Manejar cierre limpio
    # -----------------------------------------------------------
    def on_closing():
        print("\nCerrando sistema...")
        try:
            app.cerrar_aplicacion()
        except Exception as e:
            print(f"Error al cerrar app: {e}")
        try:
            esp32.detener()
        except Exception as e:
            print(f"Error al cerrar serial: {e}")
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_closing)

    # -----------------------------------------------------------
    # 5. Iniciar GUI
    # -----------------------------------------------------------
    print("Iniciando interfaz grafica...")
    root.mainloop()

if __name__ == "__main__":
    main()