# core_esp32_serial.py - VERSIÓN CORREGIDA
import serial
import serial.tools.list_ports
import time
import threading

PUERTO_PREDETERMINADO = "COM5"
BAUD = 115200


class ESP32Bridge:
    """
    Puente de comunicación serial con ESP32.
    """

    def __init__(self, port: str = PUERTO_PREDETERMINADO, baud: int = BAUD):
        self.port = port
        self.baud = baud
        self.ser = None
        self.listeners = []
        self.running = False
        self.conectado = False

    def listar_puertos(self):
        """
        Lista todos los puertos seriales disponibles.
        """
        puertos = []
        try:
            print("Buscando puertos seriales...")
            ports = serial.tools.list_ports.comports()
            
            for port in ports:
                info = {
                    'device': port.device,
                    'description': port.description,
                    'hwid': port.hwid
                }
                puertos.append(info)
                print(f"  - {port.device}: {port.description}")
                
        except Exception as e:
            print(f"Error al listar puertos: {e}")
            
        return puertos

    def conectar(self, puerto_especifico=None):
        """
        Intenta conectar al ESP32 en COM3.
        """
        puerto_a_usar = puerto_especifico or self.port
        
        try:
            print(f"Conectando a {puerto_a_usar}...")
            self.ser = serial.Serial(puerto_a_usar, self.baud, timeout=1)
            time.sleep(2)  # Dar tiempo al ESP32 para inicializar
            self.conectado = True
            print(f"CONEXION EXITOSA en {puerto_a_usar}")
            return True
            
        except Exception as e:
            print(f"ERROR: No se pudo conectar a {puerto_a_usar}")
            print(f"Razon: {e}")
            self.ser = None
            self.conectado = False
            return False

    def enviar(self, mensaje: str):
        """
        Enviar texto plano al ESP32.
        """
        try:
            if self.esta_conectado():
                self.ser.write((mensaje + "\n").encode("utf-8"))
                return True
            else:
                print("No se puede enviar: Puerto serial no conectado")
                return False
        except Exception as e:
            print(f"Error enviando mensaje: {e}")
            self.conectado = False
            return False

    def enviar_lcd(self, tipo: str, l1="", l2="", l3="", l4=""):
        """
        Enviar datos al LCD del ESP32.
        """
        if not self.esta_conectado():
            print("No se puede enviar LCD: Puerto serial no conectado")
            return False

        try:
            l1 = l1[:20]
            l2 = l2[:20]
            l3 = l3[:20]
            l4 = l4[:20]

            msg = f"{tipo},{l1},{l2},{l3},{l4}\n"
            self.ser.write(msg.encode("utf-8"))
            print(f"Enviado al LCD: {msg.strip()}")
            return True

        except Exception as e:
            print(f"Error enviando LCD: {e}")
            self.conectado = False
            return False

    def esta_conectado(self):
        """
        Verifica si la conexión está activa.
        """
        return self.conectado and self.ser and self.ser.is_open

    def agregar_listener(self, callback):
        self.listeners.append(callback)

    def iniciar_escucha(self):
        if not self.esta_conectado():
            print("No se puede escuchar: ESP32 no conectado")
            return False

        self.running = True

        def loop():
            while self.running:
                try:
                    if self.ser.in_waiting:
                        data = self.ser.readline().decode("utf-8", errors="ignore").strip()
                        if data:
                            print(f"ESP32 >>> {data}")
                            for cb in self.listeners:
                                try:
                                    cb(data)
                                except Exception as e:
                                    print(f"Error en listener: {e}")

                except Exception as e:
                    print(f"Error escuchando ESP32: {e}")
                    time.sleep(1)

                time.sleep(0.05)

        thread = threading.Thread(target=loop, daemon=True)
        thread.start()
        print("Escucha de ESP32 iniciada")
        return True

    def detener(self):
        self.running = False
        self.conectado = False
        try:
            if self.ser and self.ser.is_open:
                self.ser.close()
                print("Conexion serial cerrada")
        except Exception as e:
            print(f"Error al cerrar serial: {e}")


# Instancia global
esp32 = ESP32Bridge()

def enviar_lcd(tipo, l1="", l2="", l3="", l4=""):
    return esp32.enviar_lcd(tipo, l1, l2, l3, l4)

def listar_puertos():
    return esp32.listar_puertos()